pacman::p_load(gpinter)

## ROBUSTNESS: COMPARE WITH QUOTE
## Methodology:
## 1. Double aanmerkelijk belang, recalculate total and average wealth
## 2. Calculate at what percentile of the 0.1% distribution the Quote begins
## 3. Adjust quantile values proportionally, assuming that doubling ab
##    affects all quantiles equally.
## 4. Fit gpinter to 0.1%, extrapolate to find threshold and average of Quote.

#2011

thresholds_fit(c(0.25,0.5,0.75),c(12707.5,	14587.3,	19065.0), average = 26301.4) %>%
  fitted_quantile(0.932) #36549.89

thresholds_fit(c(0.25,0.5,0.75),c(12707.5,	14587.3,	19065.0), average = 26301.4) %>%
  bracket_average(0.932,1) #187629.8

#2012

thresholds_fit(c(0.25,0.5,0.75),c(13285.8,	15209.7,	19758.3), average = 27202.7) %>%
  fitted_quantile(0.932) #37473.08

thresholds_fit(c(0.25,0.5,0.75),c(13285.8,	15209.7,	19758.3), average = 27202.7) %>%
  bracket_average(0.932,1) #193178.4

#2013

thresholds_fit(c(0.25,0.5,0.75),c(12499.9,	14431.0,	19148.0), average = 24826.7) %>%
  fitted_quantile(0.933) #37919.24


thresholds_fit(c(0.25,0.5,0.75),c(12499.9,	14431.0,	19148.0), average = 24826.7) %>%
  bracket_average(0.93,1) #162411.1

#2014

thresholds_fit(c(0.25,0.5,0.75), c(12864.3,	14825.5,	19735.4), average = 25386.7) %>%
  fitted_quantile(0.933) #39261.1


thresholds_fit(c(0.25,0.5,0.75), c(12864.3,	14825.5,	19735.4), average = 25386.7) %>%
  bracket_average(0.933,1) #170253.8


#2015

thresholds_fit(c(0.25,0.5,0.75), c(12816.7,	14880.4,	19887.8), average = 25355.3) %>%
  fitted_quantile(0.934) #40156.25


thresholds_fit(c(0.25,0.5,0.75), c(12816.7,	14880.4,	19887.8), average = 25355.3) %>%
  bracket_average(0.934,1) #170700.5

#2016

thresholds_fit(c(0.25,0.5,0.75), c(13886.3,	16047.0,	21477.4), average = 27684.2) %>%
  fitted_quantile(0.868) #29153.98


thresholds_fit(c(0.25,0.5,0.75), c(13886.3,	16047.0,	21477.4), average = 27684.2) %>%
  bracket_average(0.868,1) #111804.8

#2017

thresholds_fit(c(0.25,0.5,0.75), c(14743.3,	16961.9,	22321.5), average = 29415.6) %>%
  fitted_quantile(0.935) #44468.62


thresholds_fit(c(0.25,0.5,0.75), c(14743.3,	16961.9,	22321.5), average = 29415.6) %>%
  bracket_average(0.935,1) #207099.4

#2018

thresholds_fit(c(0.25,0.5,0.75), c(15278.1,	17552.1,	23192.1), average = 29064.1) %>%
  fitted_quantile(0.936) #46780.79

thresholds_fit(c(0.25,0.5,0.75), c(15278.1,	17552.1,	23192.1), average = 29064.1) %>%
  bracket_average(0.936,1) #194586.3
