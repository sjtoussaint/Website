pacman::p_load(haven,tidyverse, gpinter, readxl, ptsuite)

sep <- read_spss("SepL8402WSA.por")

names(sep)

bravg <- function(x, q1, q2){
  mean(x[x>quantile(x, q1,na.rm=TRUE)&x<=quantile(x, q2,na.rm=TRUE)],na.rm=TRUE)
} #bravg calculates the bracket average between two quantiles

bravg(1:10, 0.5, 1)


## This document consists of three parts.
## 1. SEP+Forbes using gpinter. (Also includes values for 1987 -- 1992, should
##    be ignored).
## 2. SEP+Forbes using OLS and ML-Hill (Also includes values for 1987 -- 1992,
##    should be ignored).
## 3. Data generation for the Robust Pareto Regression


## PART 1: GPINTER
## STEPWISE METHODOLOGY:
# 1: convert sep from individuals to wealth (using either unique() or mean(), since reported wealth
#    of all household members is identical, so either will get the household wealth)
# 2: merge survey with rich list (forbes/quote); all values in 2002EUR
# 3: rank according to wealth
# 4: estimate percentiles from survey (from 1993 onwards, use distributional national accounts to find 'true' values; pre-1993, use average ratio with mean      (0, 0.25, 2.3)
# 5: number of guilder millionaires (converted to 2002EUR) divided by total number of households 
#    to get penultimate quantile (data from cbs)
# 6: set smallest value in rich list as the threshold for the last quantile 
#    (found by dividing by total number of households)
# 7: Calculate average household wealth by dividing total wealth over number households (cbs); adjust      to 2002EUR
# 8: calculate bracket averages between quantiles. For two highest brackets: create threshold_fit 
#    and take estimated bracketavg as bracketavg.
# 9: use quantiles (found in steps 3-5) and bracketaverages to calculate tabulation_fit and get
#    top shares.


## 1987
#f1987 <- read_xlsx("forbes_nl.xlsx", sheet = "1987")
#
#s1987 <- sep %>% group_by(GADRESNR) %>% summarise(wlth = unique(GATOTVRM,na.rm=TRUE)) %>%
#  filter(!is.na(wlth)) #pool households
#summary(s1987$wlth)
#sd(s1987$wlth)

#w1987 <- c(f1987$wlth_eur_2002,s1987$wlth)
#w1987 <- w1987 %>% sort(decreasing = TRUE)

#create quantiles (no negative values)
#eq1987 <- ecdf(s1987$wlth)(c(c(0, 0.25, 2.3)*(327519000000/5814000),655040.09))

#ps1987 <- c(0.15,0.5,0.9,0.99,0.999999656)
#qs1987 <- c(c(0, 0.25, 2.3)*(327519000000/5814000),655040.09,min(f1987$wlth_eur_2002))

#calculate bracketavg, take sep as representative until 90th percentile
#ba1987 <- vector("numeric", 5L)
#for (i in 1:2){
#  ba1987[i] <- bravg(s1987$wlth, eq1987[i], eq1987[i+1])
#}
#for (i in 3:4){
#  ba1987[i] <- thresholds_fit(ps1987,qs1987,average= 327519000000/5814000) %>% #bracket_average(ps1987[i], ps1987[i+1])
#}

#ba1987[5] <- mean(f1987$wlth_eur_2002[f1987$wlth_eur_2002 > min(f1987$wlth_eur_2002)])

#sepfit1987 <- tabulation_fit(ps1987,qs1987,bracketavg= ba1987,average= 327519000000/5814000)

#p99p100 <- vector("numeric", 16L)
#p99.5p100 <- vector("numeric", 16L)
#p99.9p100 <- vector("numeric", 16L)
#year <- 1987:2002

#sep_forbes <- tibble(year, p99p100, p99.5p100, p99.9p100)

#sep_forbes[1,2:4] <- as.list(top_share(sepfit1987,c(0.99,0.995,0.999)))


##1988

#f1988 <- read_xlsx("forbes_nl.xlsx",sheet = "1988")
#s1988 <- sep %>% group_by(IADRESNR) %>% summarise(wlth = unique(IATOTVRM,na.rm=TRUE)) %>%
#  filter(!is.na(wlth))

#w1988 <- c(f1988$wlth_eur_2002,s1988$wlth)
#w1988 <- w1988 %>% sort(decreasing = TRUE)

#summary(s1988$wlth)
#sd(s1988$wlth)

#quantiles
#eq1988 <- ecdf(s1988$wlth)(c(c(0, 0.25, 2.3)*(354971000000/5837000),655040.09))

#ps1988 <- c(0.15,0.5,0.9,0.99,0.99999948603)
#qs1988 <- c(c(0, 0.25, 2.3)*(354971000000/5837000),655040.09,min(f1988$wlth_eur_2002))

#bracketavgs
#ba1988 <- vector("numeric", 5L)
#for (i in 1:2){
# ba1988[i] <- bravg(s1988$wlth, eq1988[i], eq1988[i+1])
#}
#for (i in 3:4){
#  ba1988[i] <- thresholds_fit(ps1988,qs1988,average = 354971000000/5837000) %>% #bracket_average(ps1988[i], ps1988[i+1])
#}
#ba1988[5] <- mean(f1988$wlth_eur_2002[f1988$wlth_eur_2002 > min(f1988$wlth_eur_2002)])

#sepfit1988 <- tabulation_fit(ps1988,qs1988, bracketavg = ba1988, average = 354971000000/5837000)

#sep_forbes[2,2:4] <- as.list(top_share(sepfit1988,c(0.99,0.995,0.999)))


##1989
#f1989 <- read_xlsx("forbes_nl.xlsx", sheet = "1989")
#s1989 <- sep %>% group_by(KADRESNR) %>% summarise(wlth = unique(KATOTVRM,na.rm=TRUE)) %>%
#  filter(!is.na(wlth))

#w1989 <- c(f1989$wlth_eur_2002,s1989$wlth)
#w1989 <- w1989 %>% sort(decreasing = TRUE)

#summary(s1989$wlth)
#sd(s1989$wlth)

#quantiles
#eq1989 <- ecdf(s1989$wlth)(c(c(0, 0.25, 2.3)*(390658000000/5938000),655040.09))

#ps1989 <- c(0.15,0.5,0.9,0.988,0.99999949477)
#qs1989 <- c(c(0, 0.25, 2.3)*(390658000000/5938000),655040.09,min(f1989$wlth_eur_2002))

#bracketavg
#ba1989 <- vector("numeric", 5L)

#for (i in 1:2){
#  ba1989[i] <- bravg(s1989$wlth, eq1989[i], eq1989[i+1])
#}
#for (i in 3:4){
#  ba1989[i] <- thresholds_fit(ps1989,qs1989,average = 390658000000/5938000) %>% bracket_average(ps1989[i],ps1989[i+1])
#}  
#ba1989[5] <- mean(f1989$wlth_eur_2002[f1989$wlth_eur_2002 > min(f1989$wlth_eur_2002)])

#sepfit1989 <- tabulation_fit(ps1989,qs1989, bracketavg = ba1989, average = 390658000000/5938000)

#sep_forbes[3,2:4] <- as.list(top_share(sepfit1989, c(0.99,0.995,0.999)))


##1990
#f1990 <- read_xlsx("forbes_nl.xlsx", sheet = "1990")
#s1990 <- sep %>% group_by(MADRESNR) %>% summarise(wlth = unique(MATOTVRM,na.rm=TRUE)) %>%
#  filter(!is.na(wlth))

#w1990 <- c(f1990$wlth_eur_2002,s1990$wlth)
#w1990 <- w1990 %>% sort(decreasing = TRUE)

#summary(s1990$wlth)
#sd(s1990$wlth)

#quantiles
#eq1990 <- ecdf(s1990$wlth)(c(c(0, 0.25, 2.3)*(400411e6/6061e3),655040.09))

#ps1990 <- c(0.15,0.5,0.9,0.987,0.99999950503)
#qs1990 <- c(c(0, 0.25, 2.3)*(400411e6/6061e3),655040.09,min(f1990$wlth_eur_2002))

#bracketavg
#ba1990 <- vector("numeric", 5L)

#for (i in 1:2){
#  ba1990[i] <- bravg(s1990$wlth, eq1990[i], eq1990[i+1])
#}
#for (i in 3:4){
#  ba1990[i] <- thresholds_fit(ps1990,qs1990, average = 400411e6/6061e3) %>% bracket_average(ps1990[i],ps1990[i+1])
#}
#ba1990[5] <- mean(f1990$wlth_eur_2002[f1990$wlth_eur_2002 > min(f1990$wlth_eur_2002)])

#sepfit1990 <- tabulation_fit(ps1990,qs1990, bracketavg = ba1990, average = 400411e6/6061e3)

#sep_forbes[4,2:4] <- as.list(top_share(sepfit1990, c(0.99,0.995,0.999)))


##1991
#f1991 <- read_xlsx("forbes_nl.xlsx", sheet = "1991")
#s1991 <- sep %>% group_by(NADRESNR) %>% summarise(wlth = unique(NATOTVRM,na.rm=TRUE)) %>% 
#  filter(!is.na(wlth))

#w1991 <- c(f1991$wlth_eur_2002,s1991$wlth)
#w1991 <- w1991 %>% sort(decreasing = TRUE)

#summary(s1991$wlth)
#sd(s1991$wlth)

#quantiles
#eq1991 <- ecdf(s1991$wlth)(c(c(0, 0.25, 2.3)*(421243e6/6164e3),655040.09))

#ps1991 <- c(0.15,0.5,0.9,0.987,0.9999995133)
#qs1991 <- c(c(0, 0.25, 2.3)*(421243e6/6164e3),655040.09,min(f1991$wlth_eur_2002))

#bracketavg
#ba1991 <- vector("numeric", 5L)

#for (i in 1:2){
#  ba1991[i] <- bravg(s1991$wlth, eq1991[i], eq1991[i+1])
#}
#for (i in 3:4){
#  ba1991[i] <- thresholds_fit(ps1991,qs1991, average = 421243e6/6164e3) %>% bracket_average(ps1991[i], ps1991[i+1])
#}
#ba1991[5] <- mean(f1991$wlth_eur_2002[f1991$wlth_eur_2002 > min(f1991$wlth_eur_2002)])

#sepfit1991 <- tabulation_fit(ps1991,qs1991, bracketavg = ba1991, average = 421243e6/6164e3)

#sep_forbes[5,2:4] <- as.list(top_share(sepfit1991, c(0.99,0.995,0.999)))


##1992
#f1992 <- read_xlsx("forbes_nl.xlsx", sheet = "1992")
#s1992 <- sep %>% group_by(OADRESNR) %>% summarise(wlth = unique(OATOTVRM,na.rm=TRUE)) %>% 
#  filter(!is.na(wlth))

#w1992 <- c(f1992$wlth_eur_2002,s1992$wlth)
#w1992 <- w1992 %>% sort(decreasing = TRUE)

#summary(s1992$wlth)
#sd(s1992$wlth)

#quantiles
#eq1992 <- ecdf(s1992$wlth)(c(c(0, 0.25, 2.3)*(454772e6/6266e3),655040.09))

#ps1992 <- c(0.15,0.5,0.9,0.984,0.99999968081)
#qs1992 <- c(c(0, 0.25, 2.3)*(454772e6/6266e3),655040.09,min(f1992$wlth_eur_2002))

#bracketavg
#ba1992 <- vector("numeric", 5L)

#for (i in 1:2){
#  ba1992[i] <- bravg(s1992$wlth, eq1992[i], eq1992[i+1])
#}
#for (i in 3:4){
#  ba1992[i] <- thresholds_fit(ps1992,qs1992, average = 454772e6/6266e3) %>% bracket_average(ps1992[i],ps1992[i+1])
#} 
#ba1992[5] <- mean(f1992$wlth_eur_2002[f1992$wlth_eur_2002 > min(f1992$wlth_eur_2002)])

#sepfit1992 <- tabulation_fit(ps1992,qs1992, bracketavg = ba1992, average = 454772e6/6266e3)

#sep_forbes[6,2:4] <- as.list(top_share(sepfit1992, c(0.99,0.995,0.999)))


##1993
f1993 <- read_xlsx("forbes_nl.xlsx", sheet = "1993")
s1993 <- sep %>% group_by(PADRESNR) %>% summarise(wlth = unique(PATOTVRM,na.rm=TRUE)) %>%
  filter(!is.na(wlth))
w1993 <- c(f1993$wlth_eur,s1993$wlth)
w1993 <- w1993 %>% sort(decreasing = TRUE)

summary(s1993$wlth)
sd(s1993$wlth)

#quantiles
eq1993 <- ecdf(s1993$wlth)(c(0,20e3,50e3,100e3,200e3,500e3,1000e3))

#quantiles (TAKEN FROM CBS)
ps1993 <- c(0.117,0.545,0.71,0.853,0.942,0.987,0.996,0.99999952889)

qs1993 <- c(0,20e3,50e3,100e3,200e3,500e3,1000e3,w1993[3])

ba1993 <- vector("numeric", length = 8L)

for (i in 1:5){
  ba1993[i] <- bravg(s1993$wlth, eq1993[i], eq1993[i+1])
}

ba1993[6] <- thresholds_fit(ps1993, qs1993, average = 76.5e3) %>% bracket_average(ps1993[6], ps1993[7])

ba1993[7] <- thresholds_fit(ps1993, qs1993, average = 76.5e3) %>% bracket_average(ps1993[7], ps1993[8])

ba1993[8] <- mean(w1993[1:2])

sepfit1993 <- tabulation_fit(ps1993, qs1993, bracketavg = ba1993, average = 76.5e3)

#sep_forbes[7,2:4] <- as.list(top_share(sepfit1993, c(0.99,0.995,0.999)))


##1994
f1994 <- read_xlsx("forbes_nl.xlsx", sheet = "1994")
s1994 <- sep %>% group_by(QADRESNR) %>% summarise(wlth = unique(QATOTVRM,na.rm=TRUE)) %>%
  filter(!is.na(wlth))
w1994 <- c(f1994$wlth_eur,s1994$wlth)
w1994 <- w1994 %>% sort(decreasing = TRUE)

summary(s1994$wlth)
sd(s1994$wlth)

#bracketavg
eq1994 <- ecdf(s1994$wlth)(c(0,20e3,50e3,100e3,200e3,500e3,1000e3))

ps1994 <- c(0.125,0.531,0.687,0.837,0.937,0.986,0.996,0.99999953452)
qs1994 <- c(0,20e3,50e3,100e3,200e3,500e3,1000e3,w1994[3])

ba1994 <- vector("numeric", 8L)

for (i in 1:5){
  ba1994[i] <- bravg(s1994$wlth, eq1994[i], eq1994[i+1])
}
for (i in 6:7){
 ba1994[i] <- thresholds_fit(ps1994,qs1994, average = 79.1e3) %>% 
   bracket_average(ps1994[i],ps1994[i+1])
} 
ba1994[8] <- mean(f1994$wlth_eur_2002[f1994$wlth_eur_2002 > min(f1994$wlth_eur_2002)])
sepfit1994 <- tabulation_fit(ps1994,qs1994, bracketavg = ba1994, average = 79.1e3)

#sep_forbes[8,2:4] <- as.list(top_share(sepfit1994, c(0.99,0.995,0.999)))

##1995
f1995 <- read_xlsx("forbes_nl.xlsx", sheet = "1995")
s1995 <- sep %>% group_by(RADRESNR) %>% summarise(wlth = unique(RATOTVRM,na.rm=TRUE)) %>%
  filter(!is.na(wlth))
w1995 <- c(f1995$wlth_eur,s1995$wlth)
w1995 <- w1995 %>% sort(decreasing = TRUE)

#quantiles
summary(s1995$wlth)
sd(s1995$wlth)

eq1995 <- ecdf(s1995$wlth)(c(0,20e3,50e3,100e3,200e3,500e3,1000e3))

ps1995 <- c(0.117,0.515,0.661,0.822,0.933,0.985,0.996,0.99999953625)
qs1995 <- c(0,20e3,50e3,100e3,200e3,500e3,1000e3, w1995[3])

#bracketavg
ba1995 <- vector("numeric", 8L)

for (i in 1:5){
  ba1995[i] <- bravg(s1995$wlth, eq1995[i], eq1995[i+1])
}
for (i in 6:7){
  ba1995[i] <- thresholds_fit(ps1995, qs1995, average = 108600) %>%
    bracket_average(ps1995[i],ps1995[i+1])
}
ba1995[8] <- mean(w1995[1:2])

sepfit1995 <- tabulation_fit(ps1995, qs1995, bracketavg = ba1995, average = 108600)

#sep_forbes[9,2:4] <- as.list(top_share(sepfit1995,c(0.99,0.995,0.999)))

##1996
f1996 <- read_xlsx("forbes_nl.xlsx", sheet = "1996")
s1996 <- sep %>% group_by(SADRESNR) %>% summarise(wlth = unique(SATOTVRM,na.rm=TRUE)) %>%
  filter(!is.na(wlth))
w1996 <- c(f1996$wlth_eur,s1996$wlth)
w1996 <- w1996 %>% sort(decreasing = TRUE)

#quantiles
summary(s1996$wlth)
sd(s1996$wlth)

eq1996 <- ecdf(s1996$wlth)(c(0,20e3,50e3,100e3,200e3,500e3,1000e3))

ps1996 <- c(0.122,0.498,0.642,0.804,0.926,0.982,0.994,0.99999953973)
qs1996 <- c(0,20e3,50e3,100e3,200e3,500e3,1000e3,w1996[3])

#bracketavg
ba1996 <- vector("numeric", 8L)

for (i in 1:5){
  ba1996[i] <- bravg(s1996$wlth, eq1996[i], eq1996[i+1])
}
for (i in 6:7){
  ba1996[i] <- thresholds_fit(ps1996, qs1996, average = 117400) %>%
  bracket_average(ps1996[i],ps1996[i+1])
}
ba1996[8] <- mean(w1996[1:2])

sepfit1996 <- tabulation_fit(ps1996, qs1996, bracketavg = ba1996, average = 117400)

#sep_forbes[10,2:4] <- as.list(top_share(sepfit1996, c(0.99,0.995,0.999)))


##1997
f1997 <- read_xlsx("forbes_nl.xlsx", sheet = "1997")
s1997 <- sep %>% group_by(TADRESNR) %>% summarise(wlth = unique(TATOTVRM,na.rm=TRUE)) %>%
  filter(!is.na(wlth))
w1997 <- c(f1997$wlth_eur,s1997$wlth)
w1997 <- w1997 %>% sort(decreasing = TRUE)

#quantiles
summary(s1997$wlth)
sd(s1997$wlth)

eq1997 <- ecdf(s1997$wlth)(c(0,20e3,50e3,100e3,200e3,500e3,1000e3)) 

ps1997 <- c(0.118,0.485,0.622,0.781,0.915,0.980,0.994,0.99999939219)
qs1997 <- c(0,20e3,50e3,100e3,200e3,500e3,1000e3, w1997[4])

#bracketavg
ba1997 <- vector("numeric", 8L)

for (i in 1:5){
  ba1997[i] <- bravg(s1997$wlth, eq1997[i], eq1997[i+1])
}
for (i in 6:7){
  ba1997[i] <- thresholds_fit(ps1997, qs1997, average = 129600) %>%
    bracket_average(ps1997[i], ps1997[i+1])
} 
ba1997[8] <- mean(w1997[1:3])

sepfit1997 <- tabulation_fit(ps1997, qs1997, bracketavg = ba1997, average = 129600)

#sep_forbes[11,2:4] <- as.list(top_share(sepfit1997, c(0.99, 0.995, 0.999)))

##1998
f1998 <- read_xlsx("forbes_nl.xlsx", sheet = "1998")
s1998 <- sep %>% group_by(UADRESNR) %>% summarise(wlth = unique(UATOTVRM,na.rm=TRUE)) %>%
  filter(!is.na(wlth))
w1998 <- c(f1998$wlth_eur,s1998$wlth)
w1998 <- w1998 %>% sort(decreasing = TRUE)

#quantiles
summary(s1998$wlth)
sd(s1998$wlth)

eq1998 <- ecdf(s1998$wlth)(c(0,20e3,50e3,100e3,200e3,500e3,1000e3))

ps1998 <- c(0.130,0.503,0.621,0.760,0.903,0.978,0.993,0.99999969951)
qs1998 <- c(0,20e3,50e3,100e3,200e3,500e3,1000e3, w1998[2])

#bracketavg
ba1998 <- vector("numeric", 8L)

for (i in 1:5){
  ba1998[i] <- bravg(s1998$wlth, eq1998[i], eq1998[i+1])
}
for (i in 6:7){
  ba1998[i] <- thresholds_fit(ps1998, qs1998, average = 140800) %>%
    bracket_average(ps1998[i], ps1998[i+1])
} 
ba1998[8] <- mean(w1998[1])

sepfit1998 <- tabulation_fit(ps1998, qs1998, bracketavg = ba1998, average = 140800)

#sep_forbes[12,2:4] <- as.list(top_share(sepfit1998, c(0.99,0.995,0.999)))


##1999
f1999 <- read_xlsx("forbes_nl.xlsx", sheet = "1999")
s1999 <- sep %>% group_by(VADRESNR) %>% summarise(wlth = unique(VATOTVRM,na.rm=TRUE)) %>%
  filter(!is.na(wlth))
w1999 <- c(f1999$wlth_eur,s1999$wlth)
w1999 <- w1999 %>% sort(decreasing = TRUE)

#quantiles
summary(s1999$wlth)
sd(s1999$wlth)

eq1999 <- ecdf(s1999$wlth)(c(0,20e3,50e3,100e3,200e3,500e3,1000e3))

ps1999 <- c(0.137,0.485,0.596,0.727,0.882,0.973,0.992,0.99999940696)
qs1999 <- c(0,20e3,50e3,100e3,200e3,500e3,1000e3, w1999[4])

#bracketavg
ba1999 <- vector("numeric", 8L)

for (i in 1:5){
 ba1999[i] <- bravg(s1999$wlth, eq1999[i], eq1999[i+1])
}
for (i in 6:7){
  ba1999[i] <- thresholds_fit(ps1999, qs1999, average = 161700) %>%
    bracket_average(ps1999[i], ps1999[i+1])
} 
ba1999[8] <- mean(w1999[1:3])

sepfit1999 <- tabulation_fit(ps1999, qs1999, bracketavg = ba1999, average = 161700)

#sep_forbes[13,2:4] <- as.list(top_share(sepfit1999, c(0.99,0.995,0.999)))


##2000
f2000 <- read_xlsx("forbes_nl.xlsx", sheet = "2000")
s2000 <- sep %>% group_by(WADRESNR) %>% summarise(wlth = mean(WATOTVRM)) %>%
   filter(!is.na(wlth))
w2000 <- c(f2000$wlth_eur,s2000$wlth)
w2000 <- w2000 %>% sort(decreasing = TRUE)

#quantiles
summary(s2000$wlth)
sd(s2000$wlth)

eq2000 <- ecdf(s2000$wlth)(c(0,20e3,50e3,100e3,200e3,500e3,1000e3))

ps2000 <- c(0.136,0.477,0.574,0.690,0.851,0.967,0.989,0.99999955888)
qs2000 <- c(0,20e3,50e3,100e3,200e3,500e3,1000e3, w2000[3])

#bracketavg
ba2000 <- vector("numeric", 8L)

for (i in 1:5){
  ba2000[i] <- bravg(s2000$wlth, eq2000[i], eq2000[i+1])
}
for (i in 6:7){
  ba2000[i] <- thresholds_fit(ps2000, qs2000, average = 181200) %>%
    bracket_average(ps2000[i], ps2000[i+1])
}
ba2000[8] <- mean(w2000[1:2])

sepfit2000 <- tabulation_fit(ps2000, qs2000, bracketavg = ba2000, average = 181200)

#sep_forbes[14,2:4] <- as.list(top_share(sepfit2000, c(0.99, 0.995, 0.999)))


##2001
f2001 <- read_xlsx("forbes_nl.xlsx", sheet = "2001")
s2001 <- sep %>% group_by(XADRESNR) %>% summarise(wlth = mean(XATOTVRM,na.rm=TRUE)) %>%
  filter(!is.na(wlth))
w2001 <- c(f2001$wlth_eur,s2001$wlth)
w2001 <- w2001 %>% sort(decreasing = TRUE)

#quantiles (2.13)
summary(s2001$wlth)
sd(s2001$wlth)

eq2001 <- ecdf(s2001$wlth)(c(0,20e3,50e3,100e3,200e3,500e3,1000e3))

ps2001 <- c(0.1,0.45,0.55,0.67,0.825,0.96,0.988,0.99999970875) #estimated as average of ps2000 and ps2002 (rounded)
qs2001 <- c(0,20e3,50e3,100e3,200e3,500e3,1000e3,w2001[2])

#bracketavg
ba2001 <- vector("numeric", 8L)

for (i in 1:5){
  ba2001[i] <- bravg(s2001$wlth, eq2001[i], eq2001[i+1])
}
for (i in 6:7){
  ba2001[i] <- thresholds_fit(ps2001, qs2001, average = 192500) %>%
    bracket_average(ps2001[i], ps2001[i+1])
} 
ba2001[8] <- mean(w2001[1])

sepfit2001 <- tabulation_fit(ps2001, qs2001, bracketavg = ba2001, average = 192500)

#sep_forbes[15,2:4] <- as.list(top_share(sepfit2001, c(0.99, 0.995, 0.999)))

#ALTERNATIVE (USE SURVEY QUANTILES) (ROBUSTNESS CHECK)
qs2001_alt <- c(as.numeric(quantile(s2001$wlth,c(0.15,0.5,0.9))),1e6,w2001[2])
mean(s2001$wlth[s2001$wlth>=quantile(s2001$wlth, 0.15)&s2001$wlth<=quantile(s2001$wlth, 0.50)]) #39858.99
mean(s2001$wlth[s2001$wlth>=quantile(s2001$wlth, 0.50)&s2001$wlth<=quantile(s2001$wlth, 0.90)]) #344955.6

sepfit2001_alt <- thresholds_fit(ps2001, qs2001_alt, average = 192500)
bracket_average(sepfit2001_alt,0.9,0.99) #694575.2
bracket_average(sepfit2001_alt,0.99,0.99999970875) #1915017

sepfit2001_alt_a <- tabulation_fit(ps2001, qs2001_alt, bracketavg = c(39858.99,344955.6,694575.2,1915017,3166457547), average = 192500)
top_share(sepfit2001_alt_a,c(0.99,0.995,0.999)) #0.10889615 0.07743231 0.04051901


##2002
f2002 <- read_xlsx("forbes_nl.xlsx", sheet = "2002")
s2002 <- sep %>% group_by(YADRESNR) %>% summarise(wlth = mean(YATOTVRM,na.rm=TRUE)) %>%
  filter(!is.na(wlth))
w2002 <- c(f2002$wlth_eur,s2002$wlth)
w2002 <- w2002 %>% sort(decreasing = TRUE)

#quantiles
summary(s2002$wlth)
sd(s2002$wlth)

eq2002 <- ecdf(s2002$wlth)(c(-10e3,-5e3,0,5e3,10e3,20e3,30e3,40e3,50e3,60e3,70e3,80e3,90e3,100e3,125e3,150e3,175e3,200e3,250e3,300e3,400e3,500e3,1e6))

ps2002 <- c(0.026,0.031,0.038,0.282,0.351,0.450,0.491,0.524,0.549,0.570,0.590,0.609,0.628,0.647,0.693,0.734,0.771,0.804,0.854,0.890,0.933,0.955, 0.987, 0.99999971156)
qs2002 <- c(-10e3,-5e3,0,5e3,10e3,20e3,30e3,40e3,50e3,60e3,70e3,80e3,90e3,100e3,125e3,150e3,175e3,200e3,250e3,300e3,400e3,500e3,1e6,w2002[2])

#bracketavg
ba2002 <- vector("numeric", 24L)

for (i in 1:20){
  ba2002[i] <- bravg(s2002$wlth, eq2002[i], eq2002[i+1])
}
for (i in 21:23){
  ba2002[i] <- thresholds_fit(ps2002, qs2002, average = 198900, bottom_model = 'dirac') %>%
    bracket_average(ps2002[i], ps2002[i+1])
} 
ba2002[24] <- mean(w2002[1])

sepfit2002 <- tabulation_fit(ps2002, qs2002, bracketavg = ba2002, average = 198900, bottom_model = 'dirac')

#sep_forbes[16,2:4] <- as.list(top_share(sepfit2002, c(0.99, 0.995, 0.999)))

#write_csv(sep_forbes, "sep_forbes.csv")


## Part 2:
## STRAIGHT PARETO REGRESSIONS

# STEPWISE METHODOLOGY:
# 1. Merge SEP with Forbes
# 2. Rank observations according to wealth, in ascending order
# 3. Regress log rank on log wealth for households above 1MEUR
# 4. Do the same with ML-Hill
# 5. Includes estimates for 1987--1992 (ignore)

#1987
fit_87 <- lm(log(rank(-w1987[w1987>=1e6])-0.5)~log(w1987[w1987>=1e6]))

summary(fit_87) #0.29

plot(log(w1987[w1987>=1e6]),log(rank(-w1987[w1987>=1e6])))
abline(fit_87)

pareto <- vector("numeric", length = 16L)

mle <- vector("numeric", length = 16L)

pareto[1] <- abs(fit_87$coefficients[2])

mle_87 <- alpha_hills(w1987[w1987>0], 1e6, value = TRUE)

summary(mle_87)

mle[1] <- mle_87$shape

#1988

fit_88 <- lm(log(rank(-w1988[w1988>=1e6])-0.5)~log(w1988[w1988>=1e6]))

summary(fit_88) #0.28

pareto[2] <- abs(fit_88$coefficients[2])

mle_88 <- alpha_hills(w1988[w1988>0], 1e6, value = TRUE)

mle[2] <- mle_88$shape

#1989

fit_89 <- lm(log(rank(-w1989[w1989>=1e6])-0.5)~log(w1989[w1989>=1e6]))

summary(fit_89) #0.28

pareto[3] <- abs(fit_89$coefficients[2])

mle_89 <- alpha_hills(w1989[w1989>0], 1e6, value = TRUE)

mle[3] <- mle_89$shape


#1990

fit_90 <- lm(log(rank(-w1990[w1990>=1e6])-0.5)~log(w1990[w1990>=1e6]))

summary(fit_90) #0.27

pareto[4] <- abs(fit_90$coefficients[2])

mle_90 <- alpha_hills(w1990[w1990>0], 1e6, value = TRUE)

mle[4] <- mle_90$shape

#1991

fit_91 <- lm(log(rank(-w1991[w1991>=1e6])-0.5)~log(w1991[w1991>=1e6]))

summary(fit_91) #0.28

pareto[5] <- abs(fit_91$coefficients[2])

mle_91 <- alpha_hills(w1991[w1991>0], 1e6, value = TRUE)

mle[5] <- mle_91$shape

#1992

fit_92 <- lm(log(rank(-w1992[w1992>=1e6])-0.5)~log(w1992[w1992>=1e6]))

summary(fit_92) #0.3

pareto[6] <- abs(fit_92$coefficients[2])

mle_92 <- alpha_hills(w1992[w1992>0], 1e6, value = TRUE)

mle[6] <- mle_92$shape


#1993

fit_93 <- lm(log(rank(-w1993[w1993>=1e6])-0.5)~log(w1993[w1993>=1e6]))

summary(fit_93) #0.31

pareto[7] <- abs(fit_93$coefficients[2])

mle_93 <- alpha_hills(w1993[w1993>0], 1e6, value = TRUE)

mle[7] <- mle_93$shape


#1994

fit_94 <- lm(log(rank(-w1994[w1994>=1e6])-0.5)~log(w1994[w1994>=1e6]))

summary(fit_94) #0.37

pareto[8] <- abs(fit_94$coefficients[2])

mle_94 <- alpha_hills(w1994[w1994>0], 1e6, value = TRUE)

mle[8] <- mle_94$shape

#1995

fit_95 <- lm(log(rank(-w1995[w1995>=1e6])-0.5)~log(w1995[w1995>=1e6]))

summary(fit_95) #0.39

pareto[9] <- abs(fit_95$coefficients[2])

mle_95 <- alpha_hills(w1995[w1995>0], 1e6, value = TRUE)

mle[9] <- mle_95$shape

#1996

fit_96 <- lm(log(rank(-w1996[w1996>=1e6])-0.5)~log(w1996[w1996>=1e6]))

summary(fit_96) #0.43

pareto[10] <- abs(fit_96$coefficients[2])

mle_96 <- alpha_hills(w1996[w1996>0], 1e6, value = TRUE)

mle[10] <- mle_96$shape

#1997

fit_97 <- lm(log(rank(-w1997[w1997>=1e6])-0.5)~log(w1997[w1997>=1e6]))

summary(fit_97) #0.38

pareto[11] <- abs(fit_97$coefficients[2])

mle_97 <- alpha_hills(w1997[w1997>0], 1e6, value = TRUE)

mle[11] <- mle_97$shape

#1998

fit_98 <- lm(log(rank(-w1998[w1998>=1e6])-0.5)~log(w1998[w1998>=1e6]))

summary(fit_98) #0.62

pareto[12] <- abs(fit_98$coefficients[2])

mle_98 <- alpha_hills(w1998[w1998>0], 1e6, value = TRUE)

mle[12] <- mle_98$shape

#1999

fit_99 <- lm(log(rank(-w1999[w1999>=1e6])-0.5)~log(w1999[w1999>=1e6]))

summary(fit_99) #0.51

pareto[13] <- abs(fit_99$coefficients[2])

mle_99 <- alpha_hills(w1999[w1999>0], 1e6, value = TRUE)

mle[13] <- mle_99$shape

#2000

fit_2000 <- lm(log(rank(-w2000[w2000>=1e6])-0.5)~log(w2000[w2000>=1e6]))

summary(fit_2000) #0.66

pareto[14] <- abs(fit_2000$coefficients[2])

mle_2000 <- alpha_hills(w2000[w2000>0], 1e6, value = TRUE)

mle[14] <- mle_2000$shape

#2001

fit_2001 <- lm(log(rank(-w2001[w2001>=1e6])-0.5)~log(w2001[w2001>=1e6]))

summary(fit_2001) #0.92

pareto[15] <- abs(fit_2001$coefficients[2])

mle_2001 <- alpha_hills(w2001[w2001>0], 1e6, value = TRUE)

mle[15] <- mle_2001$shape

#2002

fit_2002 <- lm(log(rank(-w2002[w2002>=1e6])-0.5)~log(w2002[w2002>=1e6]))

summary(fit_2002) #0.44

ggplot(data = NULL, aes(x = log(w2002[w2002>=1e6]), y = log(rank(-w2002[w2002>=1e6])-0.5))) + geom_point() + geom_smooth(method = "lm", formula = y~x) +
  labs(x = "Log Wealth", y = "Log Rank - 1/2") + theme_classic() +
  scale_x_continuous(breaks = seq(14,23, by = 2))

pareto[16] <- abs(fit_2002$coefficients[2])

mle_2002 <- alpha_hills(w2002[w2002>0],1e6,value = TRUE)

mle[16] <- mle_2002$shape

mle

year <- 1987:2002

gp <- vector("numeric", length = 16L)

gp[1] <- invpareto(sepfit1987,0.99)/(invpareto(sepfit1987,0.99)-1)
gp[2] <- invpareto(sepfit1988,0.99)/(invpareto(sepfit1988,0.99)-1)
gp[3] <- invpareto(sepfit1989,0.99)/(invpareto(sepfit1989,0.99)-1)
gp[4] <- invpareto(sepfit1990,0.99)/(invpareto(sepfit1990,0.99)-1)
gp[5] <- invpareto(sepfit1991,0.99)/(invpareto(sepfit1991,0.99)-1)
gp[6] <- invpareto(sepfit1992,0.99)/(invpareto(sepfit1992,0.99)-1)
gp[7] <- invpareto(sepfit1993,0.99)/(invpareto(sepfit1993,0.99)-1)
gp[8] <- invpareto(sepfit1994,0.99)/(invpareto(sepfit1994,0.99)-1)
gp[9] <- invpareto(sepfit1995,0.99)/(invpareto(sepfit1995,0.99)-1)
gp[10] <- invpareto(sepfit1996,0.99)/(invpareto(sepfit1996,0.99)-1)
gp[11] <- invpareto(sepfit1997,0.99)/(invpareto(sepfit1997,0.99)-1)
gp[12] <- invpareto(sepfit1998,0.99)/(invpareto(sepfit1998,0.99)-1)
gp[13] <- invpareto(sepfit1999,0.99)/(invpareto(sepfit1999,0.99)-1)
gp[14] <- invpareto(sepfit2000,0.99)/(invpareto(sepfit2000,0.99)-1)
gp[15] <- invpareto(sepfit2001,0.99)/(invpareto(sepfit2001,0.99)-1)
gp[16] <- invpareto(sepfit2002,0.99)/(invpareto(sepfit2002,0.99)-1)

sep_pareto <- tibble(year,pareto,mle,gp)

write_csv(sep_pareto, "sep_pareto.csv")


# robustness check: straight pareto regressions with quote (year 2002)

quote02 <- read_xlsx("quote9619.xlsx", sheet = "2002")
names(quote02)
quote02$wlth <- as.numeric(quote02$`Net Worth (EUR)`)

w2002q <- c(quote02$wlth, s2002$wlth) %>% sort(decreasing = TRUE)

fit_02q <- lm(log(rank(-w2002q[w2002q>=1e6])-0.5)~log(w2002q[w2002q>=1e6]))

summary(fit_02q) #0.6

ggplot(data = NULL, aes(x = log(w2002q[w2002q>=1e6]), y = log(rank(-w2002q[w2002q>=1e6])-0.5))) + geom_point() + geom_smooth(method = "lm", formula = y~x) +
  labs(x = "Log Wealth", y = "Log Rank - 1/2") + theme_classic() +
  scale_x_continuous(breaks = seq(14,23, by = 2))

mle_02q <- alpha_hills(w2002q[w2002q>0], 1e6, value = TRUE) #0.24


## Step 3
## Panel data generations
## Stepwise Methodology:
## 1. Extract Data from objects above (ignore data from 1987 -- 1992)
## 2. Define functions sublm() and submle().
## 3. Apply functions to data to generate data points.
## 4. Check that gpinter doesn't work for data source.
## 5. Merge data into single dataset.

seplist <- c(ls.str(pattern = "s1", mode = "list"),ls.str(pattern = "s2", mode = "list")) %>% as.vector()

wlth <- c(s1993$wlth, s1994$wlth, s1995$wlth, s1996$wlth, s1997$wlth, s1998$wlth, s1999$wlth, s2000$wlth, s2001$wlth, s2002$wlth)

sep_list <- list()

for (i in seplist){
 sep_list[i] <- get(i)
}

year <- vector("numeric", length = length(wlth))

slength <- vector("numeric", 10L)
for (i in 1:10){
  slength[i] <- length(sep_list[[i]])
}
yval <- 1993:2002

year <- rep(yval, slength[1:10])

hh <- rep(slength, slength)

sep_wlth <- tibble(year, wlth, hh)

p595 <- sep_wlth %>% group_by(year) %>% summarise(p05 = quantile(wlth, 0.05), p95 = quantile(wlth, 0.95))

sublm <- function(data, q){
  data %>% filter(wlth > q) %>% 
    group_by(year, hh) %>% filter(n() >= 10) %>% 
    do(fit = lm(log(rank(-wlth) - 0.5) ~ log(wlth), data = .)) %>%
    do(data.frame(
      year = .$year,
      q = q,
      d = "sep",
      m = "ols",
      log_p = log(1 - (.$hh - nobs(.$fit))/.$hh),
      z = -coef(summary(.$fit))[2]))
}

ols_data <- tibble()

thr <- vector()
for (i in 1:4){
  thr[1] <- 500e3
  thr[i+1] <- 2*thr[i]
}

for (q in seq_along(thr)){
  result <- sublm(sep_wlth, thr[q])
  dat <- as_tibble(result)
  ols_data <- rbind(ols_data, dat)
}


submle <- function(data, q){
  data %>% filter(wlth > q) %>% group_by(year) %>% filter(n() >= 10) %>%
    do(fit = alpha_hills(.$wlth[.$wlth>0], q, value = TRUE)) %>% 
    do(data.frame(
      year = .$year,
      q = q,
      d = "sep",
      m = "mle",
      z = .$fit[[1]]))
}

mle_data <- tibble()

for (q in seq_along(thr)){
  result <- submle(sep_wlth, thr[q])
  dat <- as_tibble(result)
  mle_data <- rbind(mle_data, dat)
}

mle_data <- mle_data %>% filter(!is.infinite(z))

balist <- ls.str(pattern = "ba", mode = "numeric")
qslist <- ls.str(pattern = "qs", mode = "numeric")
pslist <- ls.str(pattern = "ps", mode = "numeric")

ba_list <- list()
qs_list <- list()
ps_list <- list()

ba <- vector()
for (i in balist){
  ba_list[[i]] <- get(i)
  vec <- ba_list[[i]]
  ba <- c(ba, vec)
}

qs <- vector()
for (i in qslist){
  qs_list[[i]] <- get(i)
  vec <- qs_list[[i]]
  qs <- c(qs, vec)
}

ps <- vector()
for (i in pslist){
  ps_list[[i]] <- get(i)
  vec <- ps_list[[i]]
  ps <- c(ps, vec)
}

gplength <- vector()
for (i in 1:10){
  gplength[i] <- length(ba_list[[i]])
}

year_gp <- rep(yval, gplength)

avg <- 1000*c(76.5,	79.1,	108.6,	117.4,	129.6,	140.8,	161.7,	181.2,	192.5,	198.9)

gp_input <- tibble(year_gp, ps, qs, ba) %>% arrange(desc(ps)) %>% group_by(year_gp) %>% slice(-c(1:2)) %>% arrange(year_gp, ps)

gp_data <- tibble()

b <- vector()
z <- vector()

for (i in seq_along(1:10)){
  p <- gp_input %>% filter(year_gp == yval[i]) %>% select(ps)
  q <- gp_input %>% filter(year_gp == yval[i]) %>% select(qs)
  a <- gp_input %>% filter(year_gp == yval[i]) %>% select(ba)
  fit <- tabulation_fit(p[[2]], q[[2]], bracketavg = a[[2]], average = avg[i], bottom_model = "dirac")
  b[i] <- invpareto(fit, fitted_cdf(fit, 1e6))
  z[i] <- b[i]/(b[i]-1)
  print(z)
}

#gpinter method unreliable for even 1e6, discarded

df_sep <- full_join(ols_data, mle_data)

df_sep <- df_sep %>% group_by(year, q) %>% mutate(log_p = ifelse(m == "ols", log_p, log_p[m == "ols"]))

write_csv(df_sep, "df_sep.csv")
