pacman::p_load(tidyverse,gpinter, readxl, ptsuite)

quote <- read_xlsx("quote.xlsx")

## SEP

# raw SEP data from sep.R file
# Quote data from quote.xlsx

# 1997

year <- 1997:2002
p99p100 <- vector("numeric",6L)
p99.5p100 <- vector("numeric",6L)
p99.9p100 <- vector("numeric",6L)

sep_quote <- tibble(year, p99p100, p99.5p100, p99.9p100)

sepfit1997q <- tabulation_fit(c(ps1997[1:7],quote$p[1]),c(qs1997[1:7],quote$threshold_eur[1]), bracketavg = c(ba1997[1:7],quote$bracketavg_eur[1]), average = 129600)
  
sep_quote[1,2:4] <-  as.list(top_share(sepfit1997q,c(0.99, 0.995, 0.999)))

# 1998

sepfit1998q <- tabulation_fit(c(ps1998[1:7],quote$p[2]),c(qs1998[1:7],quote$threshold_eur[2]), bracketavg = c(ba1998[1:7],quote$bracketavg_eur[2]), average = 140800) 

sep_quote[2,2:4] <- as.list(top_share(sepfit1998q, c(0.99,0.995,0.999)))

# 1999

sepfit1999q <- tabulation_fit(c(ps1999[1:7],quote$p[3]),c(qs1999[1:7],quote$threshold_eur[3]), bracketavg = c(ba1999[1:7],quote$bracketavg_eur[3]), average = 161700) 

sep_quote[3,2:4] <- as.list(top_share(sepfit1999q,c(0.99,0.995,0.999)))

# 2000

sepfit2000q <- tabulation_fit(c(ps2000[1:7],quote$p[4]),c(qs2000[1:7],quote$threshold_eur[4]), bracketavg = c(ba2000[1:7],quote$bracketavg_eur[4]), average = 181200) 

sep_quote[4,2:4] <- as.list(top_share(sepfit2000q,c(0.99,0.995,0.999)))


#2001

sepfit2001q <- tabulation_fit(c(ps2001[1:7],quote$p[5]),c(qs2001[1:7],quote$threshold_eur[5]), bracketavg = c(ba2001[1:7],quote$bracketavg_eur[5]), average = 192500) 

sep_quote[5,2:4] <- as.list(top_share(sepfit2001q,c(0.99,0.995,0.999)))


#2002

sepfit2002q <- tabulation_fit(c(ps2002[1:23],quote$p[6]),c(qs2002[1:23],quote$threshold_eur[6]), bracketavg = c(ba2002[1:23],quote$bracketavg_eur[6]), average = 198900, bottom_model = 'dirac') 

sep_quote[6,2:4] <- as.list(top_share(sepfit2002q,c(0.99,0.995,0.999)))

write_csv(sep_quote, "sep_quote.csv")

## DNB

# raw DNB data from dnb.R; quote info from quote.xlsx

# 1997

year <- 1997:2018
p99p100 <- vector("numeric", 22L)
p99.5p100 <- vector("numeric", 22L)
p99.9p100 <- vector("numeric", 22L)

dnb_quote <- tibble(year, p99p100, p99.5p100, p99.9p100)

dnbfit1997q <- tabulation_fit(c(ps1997[1:7],quote$p[1]),c(qs1997[1:7],quote$threshold_gld[1]),bracketavg = c(ba1997[1:7],quote$bracketavg_gld[1]), average = 129600*1.91)

dnb_quote[1,2:4] <- as.list(top_share(dnbfit1997q,c(0.99,0.995,0.999)))


# 1998
dnbfit1998q <- tabulation_fit(c(ps1998[1:7],quote$p[2]),c(qs1998[1:7],quote$threshold_gld[2]),bracketavg = c(ba1998[1:7],quote$bracketavg_gld[2]), average = 140800*1.95)

dnb_quote[2,2:4] <- as.list(top_share(dnbfit1998q,c(0.99,0.995,0.999)))


# 1999
dnbfit1999q <- tabulation_fit(c(ps1999[1:7],quote$p[3]),c(qs1999[1:7],quote$threshold_gld[3]),bracketavg = c(ba1999[1:7],quote$bracketavg_gld[3]), average = 2*161700)

dnb_quote[3,2:4] <- as.list(top_share(dnbfit1999q,c(0.99,0.995,0.999)))


# 2000
dnbfit2000q <- tabulation_fit(c(ps2000[1:7],quote$p[4]),c(qs2000[1:7],quote$threshold_gld[4]),bracketavg = c(ba2000[1:7],quote$bracketavg_gld[4]), average = 2.04*181200)

dnb_quote[4,2:4] <- as.list(top_share(dnbfit2000q,c(0.99,0.995,0.999)))


#2001
dnbfit2001q <- tabulation_fit(c(ps2001[1:7],quote$p[5]),c(qs2001[1:7],quote$threshold_gld[5]),bracketavg = c(ba2001[1:7],quote$bracketavg_gld[5]), average = 2.13*192500)

dnb_quote[5,2:4] <- as.list(top_share(dnbfit2001q,c(0.99,0.995,0.999)))


#2002
dnbfit2002q <- tabulation_fit(c(ps2002[1:23],quote$p[6]),c(qs2002[1:23],quote$threshold_eur[6]),bracketavg = c(ba2002[1:23],quote$bracketavg_eur[6]), average = 198900, bottom_model = 'dirac')

dnb_quote[6,2:4] <- as.list(top_share(dnbfit2002q,c(0.99,0.995,0.999)))


#2003
dnbfit2003q <- tabulation_fit(c(ps2003[1:23],quote$p[7]),c(qs2003[1:23],quote$threshold_eur[7]),bracketavg = c(ba2003[1:23],quote$bracketavg_eur[7]), average = 202900, bottom_model = 'dirac')

dnb_quote[7, 2:4] <- as.list(top_share(dnbfit2003q,c(0.99,0.995,0.999)))


#2004
dnbfit2004q <- tabulation_fit(c(ps2004[1:23],quote$p[8]),c(qs2004[1:23],quote$threshold_eur[8]),bracketavg = c(ba2004[1:23],quote$bracketavg_eur[8]), average = 213300, bottom_model = 'dirac')

dnb_quote[8, 2:4] <- as.list(top_share(dnbfit2004q,c(0.99,0.995,0.999)))


#2005
dnbfit2005q <- tabulation_fit(c(ps2005[1:23],quote$p[9]),c(qs2005[1:23],quote$threshold_eur[9]),bracketavg = c(ba2005[1:23],quote$bracketavg_eur[9]), average = 219400, bottom_model = 'dirac')

dnb_quote[9, 2:4] <- as.list(top_share(dnbfit2005q,c(0.99,0.995,0.999)))


#2006
dnbfit2006q <- tabulation_fit(c(ps2006[1:11],quote$p[10]),c(qs2006[1:11],quote$threshold_eur[10]),bracketavg = c(ba2006[1:11],quote$bracketavg_eur[10]), average = 230700, bottom_model = 'dirac')

dnb_quote[10, 2:4] <- as.list(top_share(dnbfit2006q,c(0.99,0.995,0.999)))


#2007
dnbfit2007q <- tabulation_fit(c(ps2007[1:11],quote$p[11]),c(qs2007[1:11],quote$threshold_eur[11]),bracketavg = c(ba2007[1:11],quote$bracketavg_eur[11]), average = 238700, bottom_model = 'dirac')

dnb_quote[11, 2:4] <- as.list(top_share(dnbfit2007q,c(0.99,0.995,0.999)))


#2008
dnbfit2008q <- tabulation_fit(c(ps2008[1:11],quote$p[12]),c(qs2008[1:11],quote$threshold_eur[12]),bracketavg = c(ba2008[1:11],quote$bracketavg_eur[12]), average = 243e3, bottom_model = 'dirac')

dnb_quote[12, 2:4] <- as.list(top_share(dnbfit2008q,c(0.99,0.995,0.999)))


#2009
dnbfit2009q <- tabulation_fit(c(ps2009[1:11],quote$p[13]),c(qs2009[1:11],quote$threshold_eur[13]),bracketavg = c(ba2009[1:11],quote$bracketavg_eur[13]), average = 232.4e3, bottom_model = 'dirac')

dnb_quote[13, 2:4] <- as.list(top_share(dnbfit2009q,c(0.99,0.995,0.999)))


#2010
dnbfit2010q <- tabulation_fit(c(ps2010[1:11],quote$p[14]),c(qs2010[1:11],quote$threshold_eur[14]),bracketavg = c(ba2010[1:11],quote$bracketavg_eur[14]), average = 226.9e3, bottom_model = 'dirac')

dnb_quote[14, 2:4] <- as.list(top_share(dnbfit2010q,c(0.99,0.995,0.999)))


#2011
dnbfit2011q <- tabulation_fit(c(ps2011[1:11],quote$p[15]),c(qs2011[1:11],quote$threshold_eur[15]),bracketavg = c(ba2011[1:11],quote$bracketavg_eur[15]), average = 219.2e3, bottom_model = 'dirac')

dnb_quote[15, 2:4] <- as.list(top_share(dnbfit2011q,c(0.99,0.995,0.999)))


#2012
dnbfit2012q <- tabulation_fit(c(ps2012[1:11],quote$p[16]),c(qs2012[1:11],quote$threshold_eur[16]),bracketavg = c(ba2012[1:11],quote$bracketavg_complete[16]), average = 207.1e3, bottom_model = 'dirac')

dnb_quote[16, 2:4] <- as.list(top_share(dnbfit2012q,c(0.99,0.995,0.999)))

#robustness: check with 'incomplete' thresholds

tabulation_fit(c(ps2012[1:11],quote$p[16]),c(qs2012[1:11],quote$threshold_eur[16]),bracketavg = c(ba2012[1:11],quote$bracketavg_eur[16]), average = 207.1e3, bottom_model = 'dirac') %>% top_share(c(0.99,0.995,0.999)) #0.3106322 0.2560032 0.1561854


#2013
dnbfit2013q <- tabulation_fit(c(ps2013[1:11],quote$p[17]),c(qs2013[1:11],quote$threshold_eur[17]),bracketavg = c(ba2013[1:11],quote$bracketavg_complete[17]), average = 196.6e3, bottom_model = 'dirac')

dnb_quote[17, 2:4] <- as.list(top_share(dnbfit2013q,c(0.99,0.995,0.999)))

#robustness: check with 'incomplete' thresholds

tabulation_fit(c(ps2013[1:11],quote$p[17]),c(qs2013[1:11],quote$threshold_eur[17]),bracketavg = c(ba2013[1:11],quote$bracketavg_eur[17]), average = 196.6e3, bottom_model = 'dirac') %>% top_share(c(0.99,0.995,0.999)) #0.3360522 0.2787420 0.1725719


#2014
dnbfit2014q <- tabulation_fit(c(ps2014[1:11],quote$p[18]),c(qs2014[1:11],quote$threshold_eur[18]),bracketavg = c(ba2014[1:11],quote$bracketavg_complete[18]), average = 201.9e3, bottom_model = 'dirac')

dnb_quote[18, 2:4] <- as.list(top_share(dnbfit2014q,c(0.99,0.995,0.999)))

#robustness: check with 'incomplete' thresholds

tabulation_fit(c(ps2014[1:11],quote$p[18]),c(qs2014[1:11],quote$threshold_eur[18]),bracketavg = c(ba2014[1:11],quote$bracketavg_eur[18]), average = 201.9e3, bottom_model = 'dirac') %>% top_share(c(0.99,0.995,0.999)) #0.3142205 0.2521307 0.1347545


#2015
dnbfit2015q <- tabulation_fit(c(ps2015[1:11],quote$p[19]),c(qs2015[1:11],quote$threshold_eur[19]),bracketavg = c(ba2015[1:11],quote$bracketavg_complete[19]), average = 209.6e3, bottom_model = 'dirac')

dnb_quote[19, 2:4] <- as.list(top_share(dnbfit2015q,c(0.99,0.995,0.999)))

#robustness: check with 'incomplete' thresholds

tabulation_fit(c(ps2015[1:11],quote$p[19]),c(qs2015[1:11],quote$threshold_eur[19]),bracketavg = c(ba2015[1:11],quote$bracketavg_eur[19]), average = 209.6e3, bottom_model = 'dirac') %>% top_share(c(0.99,0.995,0.999)) #0.3272354 0.2666143 0.1524767


#2016
dnbfit2016q <- tabulation_fit(c(ps2016[1:11],quote$p[20]),c(qs2016[1:11],quote$threshold_eur[20]),bracketavg = c(ba2016[1:11],quote$bracketavg_complete[20]), average = 217.2e3, bottom_model = 'dirac')

dnb_quote[20, 2:4] <- as.list(top_share(dnbfit2016q,c(0.99,0.995,0.999)))

#robustness: check with 'incomplete' thresholds

tabulation_fit(c(ps2016[1:11],quote$p[20]),c(qs2016[1:11],quote$threshold_eur[20]),bracketavg = c(ba2016[1:11],quote$bracketavg_eur[20]), average = 217.2e3, bottom_model = 'dirac') %>% top_share(c(0.99,0.995,0.999)) #0.3180197 0.2549177 0.1401823


#2017
dnbfit2017q <- tabulation_fit(c(ps2017[1:11],quote$p[21]),c(qs2017[1:11],quote$threshold_eur[21]),bracketavg = c(ba2017[1:11],quote$bracketavg_complete[21]), average = 229800, bottom_model = 'dirac')

dnb_quote[21, 2:4] <- as.list(top_share(dnbfit2017q,c(0.99,0.995,0.999)))

#robustness: check with 'incomplete' thresholds

tabulation_fit(c(ps2017[1:11],quote$p[21]),c(qs2017[1:11],quote$threshold_eur[21]),bracketavg = c(ba2017[1:11],quote$bracketavg_eur[21]), average = 229800, bottom_model = 'dirac') %>% top_share(c(0.99,0.995,0.999)) #0.3406727 0.2849604 0.1823162


#2018
dnbfit2018q <- tabulation_fit(c(ps2018[1:11],quote$p[22]),c(qs2018[1:11],quote$threshold_eur[22]),bracketavg = c(ba2018[1:11],quote$bracketavg_complete[22]), average = 245.3e3, bottom_model = 'dirac')

dnb_quote[22, 2:4] <- as.list(top_share(dnbfit2018q,c(0.99,0.995,0.999)))

#robustness: check with 'incomplete' thresholds

tabulation_fit(c(ps2018[1:11],quote$p[22]),c(qs2018[1:11],quote$threshold_eur[22]),bracketavg = c(ba2018[1:11],quote$bracketavg_eur[22]), average = 245.3e3, bottom_model = 'dirac') %>% top_share(c(0.99,0.995,0.999)) #0.3585079 0.2997246 0.1907372

write_csv(dnb_quote, "dnb_quote.csv")
