Readme

This folder contains all necessary files to replicate the main analyses of the paper. I will describe the data sources, and the R code used to 
manipulate those.

- Household Wealth: This data is taken from Statistics Netherlands, and computed in the file "wealth_nld.xlsx".

- Statistics Netherlands: The percentile breakdowns of the distribution are contained in the files "2014-vermogen-1procentgroepen-2006-2012", 
	"2019vermogensbestanddelen1procentgroepen20112018", and "2019vermogensbestanddelentop01procent20112018". I use these files for the
	analysis of doubling aanmerkelijk belang, which results in the excel file "cbs_adjusted.xlsx", and the R file "boxquote.R".

- DNB Household Survey: Sharing the microdata is not allowed without permission (which can be obtained at 
	https://www.centerdata.nl/en/databank/dhs-data-access).

- SEP: Sharing the microdata is not allowed without permission (which can be obtained at https://easy.dans.knaw.nl/ui/datasets/id/easy-dataset:39776).

- Quote: All relevant information is contained in the file "quote.xlsx".

- Forbes: All relevant information is contained in the file "forbes_nl.xlsx".


----
I use these data sources in the following R scripts:

- I compute the effects of combining DNB with Forbes in "dnb.R", SEP with Forbes in "sep.R", and both surveys with Quote in "quote.R".

- In "dnb.R", "sep.R", "cbs.R", and "richlists.R", I use the data sources to generate the data points for the Robust Panel Regressions, which I
	store in the Excel files "df_dnb", "df_sep", etc. (which are all accessible in this folder).

- In "panelreg.R", I combine all data files created in the previous step for the Robust Pareto Regressions, and I generate the figures.