pacman::p_load(haven,tidyverse, gpinter, readxl, ptsuite, rio)

hh <- 1000*c(6368,	6445,	6469,	6518,	6581,	6656,	6745,	6801,	6867,	6862,	6919,	6948,	6990,	7024.5,	7081.5,	7146,	7214.8,	7281.3,	7347.6,	7412.1,	7467.8,	7496.4,	7568.5,	7623.2,	7694.9,	7755.1)

forbes <- import_list("forbes_nl.xlsx", rbind = TRUE) %>% select(2:7)

forbes <- forbes[-c(1:10),]

plength <- forbes %>% group_by(`_file`) %>% summarise(length = length(Rank))

forbes <- forbes %>% mutate(year = rep(1987:2018, plength[[2]])) %>%
  relocate(year) %>% select(-c(2,3,5,6))

df_forbes <- forbes %>% filter(year >=1993) %>% group_by(year) %>% 
  summarise(b = mean(wlth_eur[wlth_eur > min(wlth_eur)]) / min(wlth_eur),
            z = b/(b-1),
            q = min(wlth_eur),
            d = rep("forbes", length(z)),
            m = rep("gpinter", length(z))) %>%
  mutate(log_p = log(1 - (hh - n())/hh)) %>%
  select(-b) %>% relocate(year, d, m, q)



sublm <- function(data, q){
  data %>% filter(wlth_eur > q) %>% 
    group_by(year) %>% filter(n() >= 10) %>% 
    do(fit = lm(log(rank(-wlth_eur) - 0.5) ~ log(wlth_eur), data = .)) %>%
    do(data.frame(
      year = .$year,
      q = q,
      d = "forbes",
      m = "ols",
      z = -coef(summary(.$fit))[2])
    )
}

ols_data <- sublm(forbes, 0)
ols_data[,2] <- min(forbes$wlth_eur[forbes$year == 2017]) 

submle <- function(data, q){
  data %>% filter(wlth_eur > q) %>% group_by(year) %>% 
    filter(n() >=10) %>%
    do(fit = alpha_hills(.$wlth_eur[.$wlth_eur>0], q, value = TRUE)) %>% 
    do(data.frame(
      year = .$year,
      q = q,
      d = "forbes",
      m = "mle",
      z = .$fit[[1]]))
}

mle_data <- submle(forbes, 0)
mle_data[,2] <- min(forbes$wlth_eur[forbes$year == 2017])


df_forbes <- bind_rows(df_forbes, ols_data, mle_data)

df_forbes$log_p[df_forbes$year == 2017 & df_forbes$m != "gpinter"] <- df_forbes$log_p[df_forbes$year == 2017 & df_forbes$m == "gpinter"]

write_csv(df_forbes, "df_forbes.csv")


## Quote

hh_q <- hh[5:26]

quote <- read_xlsx("quote.xlsx")

quote$bracketavg <- c(quote$bracketavg_eur[1:15],quote$bracketavg_complete[16:22])

df_quote <- quote %>% group_by(year) %>% 
  summarise(b = bracketavg/threshold_eur,
            z = b/(b-1),
            q = threshold_eur,
            d = rep("quote", length(z)),
            m = rep("gpinter", length(z)),
            log_p = log(1 - p)) %>% select(-b) %>% relocate(year, q, d, m)

df_quote <- quote %>% group_by(year) %>%
  summarise(b = bracketavg_top10/threshold_top10,z = b/(b-1),
            q = threshold_top10,
            d = rep("quote", length(z)),
            m = rep("gpinter", length(z))) %>%
  mutate(ps = (hh_q - 10)/hh_q,
         log_p = log(1 - ps)) %>%
  select(-b, -ps) %>% relocate(year, q, d, m) %>% filter(!is.na(z)) %>%
  bind_rows(df_quote)

df_quote <- quote %>% group_by(year) %>%
  summarise(b = bracketavg_top100/threshold_top100,z = b/(b-1),
            q = threshold_top100,
            d = rep("quote", length(z)),
            m = rep("gpinter", length(z))) %>%
  mutate(ps = (hh_q - 100)/hh_q,
         log_p = log(1 - ps)) %>%
  select(-b, -ps) %>% relocate(year, q, d, m) %>% filter(!is.na(z)) %>%
  bind_rows(df_quote)

df_quote <- quote %>% group_by(year) %>%
  summarise(b = bracketavg_top250/threshold_top250,z = b/(b-1),
            q = threshold_top250,
            d = rep("quote", length(z)),
            m = rep("gpinter", length(z))) %>%
  mutate(ps = (hh_q - 250)/hh_q,
         log_p = log(1 - ps)) %>%
  select(-b, -ps) %>% relocate(year, q, d, m) %>% filter(!is.na(z)) %>%
  bind_rows(df_quote)

write_csv(df_quote, "df_quote.csv")
