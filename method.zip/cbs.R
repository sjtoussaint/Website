pacman::p_load(haven,tidyverse, gpinter, readxl, ptsuite, foreach)

cbs <- read_xlsx("cbs_gpinter.xlsx")

cbs$q <- cbs$q*1000
cbs$a <- cbs$a*1000

avg <- 1000*c(76.5,	79.1,	108.6,	117.4,	129.6,	140.8,	161.7,	181.2,	192.5,	198.9, 202.9,	213.3,	219.4,	230.7,	238.7,	243.0,	232.4,	226.9,	219.2,	207.1,	196.6,	201.9,	209.6,	217.2,	229.8,	245.3
)

yval <- 1993:2018
yval <- yval[-9]

fit <- list()

b <- tibble()
z <- vector()

cdf <- tibble()

thr <- c(500e3, 1e6)

for (i in seq_along(yval)){
  p <- cbs %>% filter(year == yval[i]) %>% select(p)
  q <- cbs %>% filter(year == yval[i]) %>% select(q)
  a <- cbs %>% filter(year == yval[i]) %>% select(a)
  fit[[i]] <- tabulation_fit(p[[1]], q[[1]], bracketavg = a[[1]], average = avg[i], bottom_model = "dirac")
  for (j in 1:2){
  cdf[i,j] <- fitted_cdf(fit[[i]],thr[j])
    b[i,j] <- invpareto(fit[[i]], fitted_cdf(fit[[i]],thr[j]))
}
  
}

colnames(b) <- thr

colnames(cdf) <- thr
 
df_cbs <- b  %>% pivot_longer(1:2, names_to = "q", values_to = "b") %>%
  mutate(year = rep(yval, each = 2),
         z = b/(b-1), 
         d = rep("cbs", length(z)), 
         m = rep("gpinter", length(z))) %>% 
  relocate(year, q, d, m, z) %>% select(-b)

cdf <- cdf %>% pivot_longer(1:2, names_to = "q", values_to = "cdf") %>%
  mutate(year = rep(yval, each = 2),
         log_p = log(1 - cdf), 
         d = rep("cbs", length(year)), 
         m = rep("gpinter", length(year)))

df_cbs <- full_join(df_cbs, cdf)

write_csv(df_cbs, "df_cbs.csv")


