pacman::p_load(tidyverse,gpinter,readxl,haven, stargazer, ptsuite)

bravg <- function(x, q1, q2){
  mean(x[x>quantile(x, q1,na.rm=TRUE)&x<=quantile(x, q2,na.rm=TRUE)],na.rm=TRUE)
} #bravg calculates the bracket average between two quantiles

bravg(1:10, 0.5, 1)

## This document has three parts:
## Part 1: Combining DNB + Forbes using generalized Pareto interpolation.
## Part 2: Combining DNB + Forbes using OLS and Maximum Likelihood
## Part 3: Generating the data for the Robust Pareto Regression, only using DNB


## PART 1: GPINTER
## STEPWISE METHODOLOGY:
# 1: convert dnb from individuals to household (using sum(), since joint wealth is reported by only       one household member)
# 2: merge survey with rich list (forbes/quote); values in guilders (until 2002), EUR (from 2002)
# 3: rank according to wealth
# 4: estimate percentiles from survey, use distributional national accounts to find 'true' values for percentiles; extrapolate backwards for pre-1993.
# 5: number of guilder millionaires (converted to 2002EUR) divided by total number of households 
#    to get penultimate quantile (data from cbs)
# 6: set smallest value in rich list as the threshold for the last quantile 
#    (found by dividing by total number of households)
# 7: Use distributional accounts for average household wealth (pre-1995, use CPB estimates)
# 8: calculate bracket averages between quantiles. For two highest brackets: create threshold_fit 
#    and take estimated bracketavg as bracketavg.
# 9: use quantiles (found in steps 3-5) and bracketaverages to calculate tabulation_fit and get
#    top shares.

##1993
f1993 <- read_xlsx("forbes_nl.xlsx", sheet = "1993")
d1993 <- read_dta("agw1993en_2.0.dta")
d1993[is.na(d1993)] <- 0
s1993 <- d1993 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b5b+b6b+b7b+b8b+b9b+b11b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w1993 <- c(f1993$wlth_gld,s1993$agwlth)
w1993 <- w1993 %>% sort(decreasing = TRUE)

summary(s1993$agwlth)
sd(s1993$agwlth)

s1993 %>% summarise(p99p100 = sum(s1993$agwlth[s1993$agwlth>=quantile(s1993$agwlth,0.99)]/sum(s1993$agwlth))) #0.0949

#quantiles (from CBS) (2002EUR to 1993gld = *1.75)
quantile(s1993$agwlth, c(0.117,0.545,0.71,0.853,0.942,0.987,0.996))

eq1993 <- ecdf(s1993$agwlth)(1.75*c(0,20e3,50e3,100e3,200e3,500e3,1000e3))

ps1993 <- c(0.117,0.545,0.71,0.853,0.942,0.987,0.996,0.99999952889)
qs1993 <- c(1.75*c(0,20e3,50e3,100e3,200e3,500e3,1000e3), w1993[3])

#bracketavg (use CBS quantiles)
ba1993 <- vector("numeric", length = 8L)

for (i in 1:5){
  ba1993[i] <- bravg(s1993$agwlth, eq1993[i], eq1993[i+1])
}

ba1993[6] <- thresholds_fit(ps1993, qs1993, average = 76.5e3) %>% bracket_average(ps1993[6], ps1993[7])

ba1993[7] <- thresholds_fit(ps1993, qs1993, average = 76.5e3) %>% bracket_average(ps1993[7], ps1993[8])

ba1993[8] <- mean(w1993[1:2])

dnbfit1993 <- tabulation_fit(ps1993, qs1993, bracketavg = ba1993, average = 76.5e3)

year <- 1993:2018
p99p100 <- vector("numeric", length = 26L)
p99.5p100 <- vector("numeric", length = 26L)
p99.9p100 <- vector("numeric", length = 26L) 

dnb_forbes <- tibble(year, p99p100, p99.5p100, p99.9p100)
dnb_forbes[1,2:4] <- as.list(top_share(dnbfit1993, c(0.99, 0.995, 0.999)))


##1994
f1994 <- read_xlsx("forbes_nl.xlsx", sheet = "1994")
d1994 <- read_dta("agw1994en_2.0.dta")
d1994[is.na(d1994)] <- 0
s1994 <- d1994 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b5b+b6b+b7b+b8b+b9b+b11b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))

w1994 <- c(f1994$wlth_gld,s1994$agwlth)
w1994 <- w1994 %>% sort(decreasing = TRUE)

summary(s1994$agwlth)
sd(s1994$agwlth)

s1994 %>% summarise(p99p100 = sum(s1994$agwlth[s1994$agwlth>=quantile(s1994$agwlth,0.99)]/sum(s1994$agwlth))) #0.130

#quantiles (*1.8)
eq1994 <- ecdf(s1994$agwlth)(1.8*c(0,20e3,50e3,100e3,200e3,500e3,1000e3))

ps1994 <- c(0.125,0.531,0.687,0.837,0.937,0.986,0.996,0.99999953452)
qs1994 <- c(1.8*c(0,20e3,50e3,100e3,200e3,500e3,1000e3),w1994[3])

ba1994 <- vector("numeric", 8L)

for (i in 1:5){
  ba1994[i] <- bravg(s1994$agwlth, eq1994[i], eq1994[i+1])
}

ba1994[6] <- thresholds_fit(ps1994, qs1994, average = 79.1e3) %>% bracket_average(ps1994[6], ps1994[7])

ba1994[7] <- thresholds_fit(ps1994, qs1994, average = 79.1e3) %>% bracket_average(ps1994[7], ps1994[8])

ba1994[8] <- mean(w1994[1:2])

dnbfit1994 <- tabulation_fit(ps1994, qs1994, bracketavg = ba1994, average = 79.1e3)

dnb_forbes[2,2:4] <- as.list(top_share(dnbfit1994, c(0.99,0.995,0.999)))


##1995
f1995 <- read_xlsx("forbes_nl.xlsx", sheet = "1995")
d1995 <- read_dta("agw1995en_2.0.dta")
d1995[is.na(d1995)] <- 0
s1995 <- d1995 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b5b+b6b+b7b+b8b+b9b+b11b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w1995 <- c(f1995$wlth_gld,s1995$agwlth)
w1995 <- w1995 %>% sort(decreasing = TRUE)

summary(s1995$agwlth)
sd(s1995$agwlth)

s1995 %>% summarise(p99p100 = sum(s1995$agwlth[s1995$agwlth>=quantile(s1995$agwlth,0.99)]/sum(s1995$agwlth))) #0.0929

#quantiles (*1.83)
eq1995 <- ecdf(s1995$agwlth)(1.83*c(0,20e3,50e3,100e3,200e3,500e3,1000e3)) #0.1982634 0.3621563 0.7916064 0.9974674

ps1995 <- c(0.117,0.515,0.661,0.822,0.933,0.985,0.996,0.99999953625)
qs1995 <- c(1.83*c(0,20e3,50e3,100e3,200e3,500e3,1000e3),w1995[3])

#bracketavg
ba1995 <- vector("numeric", 8L)
for (i in 1:6){
  ba1995[i] <- bravg(s1995$agwlth, eq1995[i], eq1995[i+1])
}
ba1995[6] <- thresholds_fit(ps1995, qs1995, average = 108600*1.83) %>% 
  bracket_average(ps1995[6],ps1995[7])
ba1995[7] <- thresholds_fit(ps1995, qs1995, average = 108600*1.83) %>% 
  bracket_average(ps1995[7],ps1995[8])
ba1995[8] <- mean(w1995[1:2])

dnbfit1995 <- tabulation_fit(ps1995, qs1995, bracketavg = ba1995, average = 108600*1.83)

dnb_forbes[3,2:4] <- as.list(top_share(dnbfit1995, c(0.99, 0.995, 0.999)))


##1996
f1996 <- read_xlsx("forbes_nl.xlsx", sheet = "1996")
d1996 <- read_dta("agw1996en_2.0.dta")
d1996[is.na(d1996)] <- 0
s1996 <- d1996 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b5b+b6b+b7b+b8b+b9b+b11b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w1996 <- c(f1996$wlth_gld,s1996$agwlth) %>% sort(decreasing = TRUE)

summary(s1996$agwlth)
sd(s1996$agwlth)

s1996 %>% summarise(p99p100 = sum(s1996$agwlth[s1996$agwlth>=quantile(s1996$agwlth,0.99)]/sum(s1996$agwlth))) #0.0847

#quantiles (1.87)
eq1996 <- ecdf(s1996$agwlth)(1.87*c(0,20e3,50e3,100e3,200e3,500e3,1000e3)) #0.2133492 0.3587604 0.8001589 0.9980135

ps1996 <- c(0.122,0.498,0.642,0.804,0.926,0.982,0.994,0.99999953973)
qs1996 <- c(1.87*c(0,20e3,50e3,100e3,200e3,500e3,1000e3), w1996[3])

#bracketavg
ba1996 <- vector("numeric",8L)

for (i in 1:6){
  ba1996[i] <- bravg(s1996$agwlth, eq1996[i], eq1996[i+1])
}
ba1996[6] <- thresholds_fit(ps1996, qs1996, average = 117400*1.87) %>%
  bracket_average(ps1996[6],ps1996[7])
ba1996[7] <- thresholds_fit(ps1996, qs1996, average = 117400*1.87) %>%
  bracket_average(ps1996[7],ps1996[8])
ba1996[8] <- mean(f1996$wlth_gld[f1996$wlth_gld > min(f1996$wlth_gld)])

dnbfit1996 <- tabulation_fit(ps1996, qs1996, bracketavg = ba1996, average = 117400*1.87)

dnb_forbes[4,2:4] <- as.list(top_share(dnbfit1996, c(0.99, 0.995, 0.999)))


##1997
f1997 <- read_xlsx("forbes_nl.xlsx", sheet = "1997")
d1997 <- read_dta("agw1997en_3.0.dta")
d1997[is.na(d1997)] <- 0
s1997 <- d1997 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b5b+b6b+b7b+b8b+b11b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))


summary(s1997$agwlth)
sd(s1997$agwlth)

#remove outlier of 88M

s1997 <- s1997 %>% filter(agwlth != max(agwlth))

w1997 <- c(f1997$wlth_gld,s1997$agwlth) %>% sort(decreasing = TRUE)

s1997 %>% summarise(p99p100 = sum(s1997$agwlth[s1997$agwlth>=quantile(s1997$agwlth,0.99)]/sum(s1997$agwlth))) #0.104

#quantiles (1.91)
eq1997 <- ecdf(s1997$agwlth)(1.91*c(0,20e3,50e3,100e3,200e3,500e3,1000e3))

ps1997 <- c(0.118,0.485,0.622,0.781,0.915,0.980,0.994,0.99999939219)
qs1997 <- c(1.91*c(0,20e3,50e3,100e3,200e3,500e3,1000e3), w1997[4])

#bracketavg
ba1997 <- vector("numeric",8L)
for (i in 1:6){
  ba1997[i] <- bravg(s1997$agwlth, eq1997[i], eq1997[i+1])
}
ba1997[6] <- thresholds_fit(ps1997,qs1997, average = 129600*1.91) %>%
  bracket_average(ps1997[6],ps1997[7])
ba1997[7] <- thresholds_fit(ps1997,qs1997, average = 129600*1.91) %>%
  bracket_average(ps1997[7],ps1997[8])
ba1997[8] <- mean(w1997[1:3])

dnbfit1997 <- tabulation_fit(ps1997,qs1997, bracketavg = ba1997, average = 129600*1.91)

dnb_forbes[5,2:4] <- as.list(top_share(dnbfit1997, c(0.99,0.995,0.999)))


##1998
f1998 <- read_xlsx("forbes_nl.xlsx", sheet = "1998")
d1998 <- read_dta("agw1998en_3.0.dta")
d1998[is.na(d1998)] <- 0
s1998 <- d1998 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b5b+b6b+b7b+b8b+b11b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w1998 <- c(f1998$wlth_gld,s1998$agwlth) %>% sort(decreasing = TRUE)

summary(s1998$agwlth)
sd(s1998$agwlth)

s1998 %>% summarise(p99p100 = sum(s1998$agwlth[s1998$agwlth>=quantile(s1998$agwlth,0.99)]/sum(s1998$agwlth))) #0.119

#quantiles (1.95)
eq1998 <- ecdf(s1998$agwlth)(1.95*c(0,20e3,50e3,100e3,200e3,500e3,1000e3))

ps1998 <- c(0.130,0.503,0.621,0.760,0.903,0.978,0.993,0.99999969951)
qs1998 <- c(1.95*c(0,20e3,50e3,100e3,200e3,500e3,1000e3),w1998[2])

#bracketavg
ba1998 <- vector("numeric",8L)
for (i in 1:6){
  ba1998[i] <- bravg(s1998$agwlth, eq1998[i], eq1998[i+1])
}

ba1998[6] <-thresholds_fit(ps1998, qs1998, average = 140800*1.95) %>%
  bracket_average(ps1998[6],ps1998[7])
ba1998[7] <-thresholds_fit(ps1998, qs1998, average = 140800*1.95) %>%
  bracket_average(ps1998[7],ps1998[8])
ba1998[8] <-w1998[1]

dnbfit1998 <- tabulation_fit(ps1998, qs1998, bracketavg = ba1998, average = 140800*1.95)

dnb_forbes[6,2:4] <- as.list(top_share(dnbfit1998, c(0.99, 0.995, 0.999)))


##1999
f1999 <- read_xlsx("forbes_nl.xlsx", sheet = "1999")
d1999 <- read_dta("agw1999en_3.0.dta")
d1999[is.na(d1999)] <- 0
s1999 <- d1999 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b5b+b6b+b7b+b8b+b11b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w1999 <- c(f1999$wlth_gld,s1999$agwlth) %>% sort(decreasing = TRUE)

summary(s1999$agwlth)
sd(s1999$agwlth)

s1999 %>% summarise(p99p100 = sum(s1999$agwlth[s1999$agwlth>=quantile(s1999$agwlth,0.99)]/sum(s1999$agwlth))) #0.111

#quantiles (2)
eq1999 <- ecdf(s1999$agwlth)(2*c(0,20e3,50e3,100e3,200e3,500e3,1000e3))

ps1999 <- c(0.137,0.485,0.596,0.727,0.882,0.973,0.992,0.99999940696)
qs1999 <- c(2*c(0,20e3,50e3,100e3,200e3,500e3,1000e3), w1999[4])

#bracketavg
ba1999 <- vector("numeric",8L)
for (i in 1:6){
  ba1999[i] <- bravg(s1999$agwlth, eq1999[i], eq1999[i+1])
}

ba1999[6] <- thresholds_fit(ps1999, qs1999, average = 2*161700) %>%
  bracket_average(ps1999[6],ps1999[7])
ba1999[7] <- thresholds_fit(ps1999, qs1999, average = 2*161700) %>%
  bracket_average(ps1999[7],ps1999[8])
ba1999[8] <- mean(w1999[1:3])

dnbfit1999 <- tabulation_fit(ps1999, qs1999, bracketavg = ba1999, average = 2*161700)

dnb_forbes[7,2:4] <- as.list(top_share(dnbfit1999, c(0.99, 0.995, 0.999)))


##2000
f2000 <- read_xlsx("forbes_nl.xlsx", sheet = "2000")
d2000 <- read_dta("agw2000en_2.0.dta")
d2000[is.na(d2000)] <- 0
s2000 <- d2000 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b11b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2000 <- c(f2000$wlth_gld,s2000$agwlth) %>% sort(decreasing = TRUE)

summary(s2000$agwlth)
sd(s2000$agwlth)

s2000 %>% summarise(p99p100 = sum(s2000$agwlth[s2000$agwlth>=quantile(s2000$agwlth,0.99)]/sum(s2000$agwlth))) #0.137

#quantiles (2.04)
eq2000 <- ecdf(s2000$agwlth)(2.04*c(0,20e3,50e3,100e3,200e3,500e3,1000e3))

ps2000 <- c(0.136,0.477,0.574,0.690,0.851,0.967,0.989,0.99999955888)
qs2000 <- c(2.04*c(0,20e3,50e3,100e3,200e3,500e3,1000e3), w2000[3])

#bracketavg
ba2000 <- vector("numeric",8L)
for (i in 1:6){
  ba2000[i] <- bravg(s2000$agwlth, eq2000[i], eq2000[i+1])
}

ba2000[6] <- thresholds_fit(ps2000, qs2000, average = 2.04*181200) %>%
  bracket_average(ps2000[6],ps2000[7])
ba2000[7] <- thresholds_fit(ps2000, qs2000, average = 2.04*181200) %>%
  bracket_average(ps2000[7],ps2000[8])
ba2000[8] <- mean(w2000[1:2])

dnbfit2000 <- tabulation_fit(ps2000, qs2000, bracketavg = ba2000, average = 2.04*181200)

dnb_forbes[8,2:4] <- as.list(top_share(dnbfit2000, c(0.99, 0.995, 0.999)))


##2001
f2001 <- read_xlsx("forbes_nl.xlsx", sheet = "2001")
d2001 <- read_dta("agw2001en_2.0.dta")
d2001[is.na(d2001)] <- 0
s2001 <- d2001 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b11b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2001 <- c(f2001$wlth_gld,s2001$agwlth) %>% sort(decreasing = TRUE)

summary(s2001$agwlth)
sd(s2001$agwlth)

s2001 %>% summarise(p99p100 = sum(s2001$agwlth[s2001$agwlth>=quantile(s2001$agwlth,0.99)]/sum(s2001$agwlth))) #0.127

#quantiles (2.13)
eq2001 <- ecdf(s2001$agwlth)(2.13*c(0,20e3,50e3,100e3,200e3,500e3,1000e3))

ps2001 <- c(0.1,0.45,0.55,0.67,0.825,0.96,0.988,0.99999970875) #estimated as average of ps2000 and ps2002 (rounded)
qs2001 <- c(2.13*c(0,20e3,50e3,100e3,200e3,500e3,1000e3), w2001[2])

#bracketavg
ba2001 <- vector("numeric",8L)
for (i in 1:6){
  ba2001[i] <- bravg(s2001$agwlth, eq2001[i], eq2001[i+1])
}

ba2001[6] <- thresholds_fit(ps2001, qs2001, average = 2.13*192500) %>%
  bracket_average(ps2001[6],ps2001[7])
ba2001[7] <- thresholds_fit(ps2001, qs2001, average = 2.13*192500) %>%
  bracket_average(ps2001[7],ps2001[8])
ba2001[8] <- mean(w2001[1])

dnbfit2001 <- tabulation_fit(ps2001, qs2001, bracketavg = ba2001, average = 2.13*192500)

dnb_forbes[9,2:4] <- as.list(top_share(dnbfit2001, c(0.99, 0.995, 0.999)))


##2002
f2002 <- read_xlsx("forbes_nl.xlsx", sheet = "2002")
d2002 <- read_dta("agw2002en_2.0.dta")
d2002[is.na(d2002)] <- 0
s2002 <- d2002 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b11b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2002 <- c(f2002$wlth_eur, s2002$agwlth) %>% sort(decreasing = TRUE)

summary(s2002$agwlth)
sd(s2002$agwlth)

s2002 %>% summarise(p99p100 = sum(s2002$agwlth[s2002$agwlth>=quantile(s2002$agwlth,0.99)]/sum(s2002$agwlth))) #0.0987

#quantiles
eq2002 <- ecdf(s2002$agwlth)(c(-10e3,-5e3,0,5e3,10e3,20e3,30e3,40e3,50e3,60e3,70e3,80e3,90e3,100e3,125e3,150e3,175e3,200e3,250e3,300e3,400e3,500e3,1e6))

ps2002 <- c(0.026,0.031,0.038,0.282,0.351,0.450,0.491,0.524,0.549,0.570,0.590,0.609,0.628,0.647,0.693,0.734,0.771,0.804,0.854,0.890,0.933,0.955,0.987, 0.99999971156)
qs2002 <- c(-10e3,-5e3,0,5e3,10e3,20e3,30e3,40e3,50e3,60e3,70e3,80e3,90e3,100e3,125e3,150e3,175e3,200e3,250e3,300e3,400e3,500e3,1e6, w2002[2])

#bracketavg
ba2002 <- vector("numeric",24L)
for (i in 1:20){
  ba2002[[i]] <- bravg(s2002$agwlth, eq2002[i], eq2002[i+1])
}
for (i in 21:23){
  ba2002[i] <- thresholds_fit(ps2002, qs2002, average = 198900,bottom_model = 'dirac') %>%
    bracket_average(ps2002[i],ps2002[i+1])
}
ba2002[24] <- mean(w2002[1])

dnbfit2002 <- tabulation_fit(ps2002, qs2002, bracketavg = ba2002, average = 198900, bottom_model = 'dirac')

dnb_forbes[10,2:4] <- as.list(top_share(dnbfit2002, c(0.99, 0.995, 0.999)))


##2003
f2003 <- read_xlsx("forbes_nl.xlsx", sheet = "2003")
d2003 <- read_dta("agw2003en_2.0.dta")
d2003[is.na(d2003)] <- 0
s2003 <- d2003 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b11b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2003 <- c(f2003$wlth_eur, s2003$agwlth) %>% sort(decreasing = TRUE)

summary(s2003$agwlth)
sd(s2003$agwlth)

s2003 %>% summarise(p99p100 = sum(s2003$agwlth[s2003$agwlth>=quantile(s2003$agwlth,0.99)]/sum(s2003$agwlth))) #0.0885

#quantiles
eq2003 <- ecdf(s2003$agwlth)(c(-10e3,-5e3,0,5e3,10e3,20e3,30e3,40e3,50e3,60e3,70e3,80e3,90e3,100e3,125e3,150e3,175e3,200e3,250e3,300e3,400e3,500e3,1e6))

ps2003 <- c(0.029,0.034,0.041,0.285,0.352,0.424,0.481,0.510,0.532,0.552,0.572,0.590,0.607,0.625,0.668,0.709,0.748,0.782,0.836,0.875,0.923,0.949,0.985, 0.99999942824)
qs2003 <- c(-10e3,-5e3,0,5e3,10e3,20e3,30e3,40e3,50e3,60e3,70e3,80e3,90e3,100e3,125e3,150e3,175e3,200e3,250e3,300e3,400e3,500e3,1e6, w2003[4])

#bracketavg
ba2003 <- vector("numeric",24L)

for (i in 1:20){
  ba2003[i] <- bravg(s2003$agwlth, eq2003[i], eq2003[i+1])
}
for (i in 21:23){
  ba2003[i] <- thresholds_fit(ps2003, qs2003, average = 202900, bottom_model = 'dirac') %>% bracket_average(ps2003[i],ps2003[i+1])
} 
ba2003[24] <- mean(w2003[1:3])

dnbfit2003 <- tabulation_fit(ps2003, qs2003, bracketavg = ba2003, average = 202900, bottom_model = 'dirac')

dnb_forbes[11,2:4] <- as.list(top_share(dnbfit2003, c(0.99, 0.995, 0.999)))


##2004
f2004 <- read_xlsx("forbes_nl.xlsx", sheet = "2004")
d2004 <- read_dta("agw2004en_3.1.dta")
d2004[is.na(d2004)] <- 0
s2004 <- d2004 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b11b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2004 <- c(f2004$wlth_eur, s2004$agwlth) %>% sort(decreasing = TRUE)

summary(s2004$agwlth)
sd(s2004$agwlth)

s2004 %>% summarise(p99p100 = sum(s2004$agwlth[s2004$agwlth>=quantile(s2004$agwlth,0.99)]/sum(s2004$agwlth))) #0.101

#quantiles
eq2004 <- ecdf(s2004$agwlth)(c(-10e3,-5e3,0,5e3,10e3,20e3,30e3,40e3,50e3,60e3,70e3,80e3,90e3,100e3,125e3,150e3,175e3,200e3,250e3,300e3,400e3,500e3,1e6))
ps2004 <- c(0.036,0.042,0.052,0.299,0.360,0.428,0.485,0.512,0.537,0.557,0.575,0.593,0.610,0.627,0.670,0.710,0.746,0.780,0.834,0.874,0.923,0.949,0.986, 0.99999943254)
qs2004 <- c(-10e3,-5e3,0,5e3,10e3,20e3,30e3,40e3,50e3,60e3,70e3,80e3,90e3,100e3,125e3,150e3,175e3,200e3,250e3,300e3,400e3,500e3,1e6, w2004[4])

#bracketavg
ba2004 <- vector("numeric", 24L)

for (i in 1:20){
  ba2004[i] <- bravg(s2004$agwlth, eq2004[i], eq2004[i+1])
}
for (i in 21:23){
  ba2004[i] <- thresholds_fit(ps2004, qs2004, average = 213300, bottom_model = 'dirac') %>% 
    bracket_average(ps2004[i], ps2004[i+1])
}
ba2004[24] <- mean(w2004[1:3])

dnbfit2004 <- tabulation_fit(ps2004, qs2004, bracketavg = ba2004, average = 213300, bottom_model = 'dirac')

dnb_forbes[12,2:4] <- as.list(top_share(dnbfit2004, c(0.99, 0.995, 0.999)))


##2005
f2005 <- read_xlsx("forbes_nl.xlsx", sheet = "2005")
d2005 <- read_dta("agw2005en_3.1.dta")
d2005[is.na(d2005)] <- 0
s2005 <- d2005 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b11b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2005 <- c(f2005$wlth_eur, s2005$agwlth) %>% sort(decreasing = TRUE)

summary(s2005$agwlth)
sd(s2005$agwlth)

s2005 %>% summarise(p99p100 = sum(s2005$agwlth[s2005$agwlth>=quantile(s2005$agwlth,0.99)]/sum(s2005$agwlth))) #0.102

#quantiles
eq2005 <- ecdf(s2005$agwlth)(c(-10e3,-5e3,0,5e3,10e3,20e3,30e3,40e3,50e3,60e3,70e3,80e3,90e3,100e3,125e3,150e3,175e3,200e3,250e3,300e3,400e3,500e3,1e6)) 

ps2005 <- c(0.038,0.044,0.052,0.297,0.355,0.422,0.476,0.503,0.527,0.546,0.564,0.581,0.599,0.615,0.656,0.695,0.732,0.765,0.822,0.862,0.915,0.944,0.985, 0.9999994359)
qs2005 <- c(-10e3,-5e3,0,5e3,10e3,20e3,30e3,40e3,50e3,60e3,70e3,80e3,90e3,100e3,125e3,150e3,175e3,200e3,250e3,300e3,400e3,500e3,1e6, w2005[4])

#bracketavg
ba2005 <- vector("numeric", 24L)

for (i in 1:20){
  ba2005[i] <- bravg(s2005$agwlth, eq2005[i], eq2005[i+1])
}

for (i in 21:23){
  ba2005[i] <- thresholds_fit(ps2005, qs2005, average = 219400, bottom_model = 'dirac') %>% 
    bracket_average(ps2005[i], ps2005[i+1])
}
ba2005[24] <- mean(w2005[1:3])

dnbfit2005 <- tabulation_fit(ps2005, qs2005, bracketavg = ba2005, average = 219400, bottom_model = 'dirac')

dnb_forbes[13,2:4] <-  as.list(top_share(dnbfit2005, c(0.99, 0.995, 0.999)))


##2006
f2006 <- read_xlsx("forbes_nl.xlsx", sheet = "2006")
d2006 <- read_dta("agw2006en_3.1.dta")
d2006[is.na(d2006)] <- 0
s2006 <- d2006 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b11b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2006 <- c(f2006$wlth_eur, s2006$agwlth) %>% sort(decreasing = TRUE)


summary(s2006$agwlth)
sd(s2006$agwlth)

s2006 %>% summarise(p99p100 = sum(s2006$agwlth[s2006$agwlth>=quantile(s2006$agwlth,0.99)]/sum(s2006$agwlth))) #0.0967

#quantiles
eq2006 <- ecdf(s2006$agwlth)(c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6))
ps2006 <- c(0.048,0.056,0.202,0.305,0.362,0.429,0.532,0.615,0.756,0.933,0.982, 0.99999944024)
qs2006 <- c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6, f2005$wlth_eur[4])

#bracketavg
ba2006 <- vector("numeric", 12L)

for (i in 1:9){
  ba2006[i] <- bravg(s2006$agwlth, eq2006[i], eq2006[i+1])
}
for (i in 10:11){
  ba2006[i] <- thresholds_fit(ps2006, qs2006, average = 230700, bottom_model = 'dirac') %>% bracket_average(ps2006[i], ps2006[i+1]) 
}
ba2006[12] <- mean(f2006$wlth_eur[f2006$wlth_eur > min(f2006$wlth_eur)])

dnbfit2006 <- tabulation_fit(ps2006, qs2006, bracketavg = ba2006, average = 230700, bottom_model = 'dirac')

dnb_forbes[14,2:4] <- as.list(top_share(dnbfit2006, c(0.99, 0.995, 0.999)))


##2007
f2007 <- read_xlsx("forbes_nl.xlsx", sheet = "2007")
d2007 <- read_dta("agw2007en_3.0.dta")
d2007[is.na(d2007)] <- 0
s2007 <- d2007 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b11b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2007 <- c(f2007$wlth_eur, s2007$agwlth) %>% sort(decreasing = TRUE)

summary(s2007$agwlth)
sd(s2007$agwlth)

s2007 %>% summarise(p99p100 = sum(s2007$agwlth[s2007$agwlth>=quantile(s2007$agwlth,0.99)]/sum(s2007$agwlth))) #0.108

#quantiles
eq2007 <- ecdf(s2007$agwlth)(c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6))

ps2007 <- c(0.042,0.050,0.192,0.296,0.352,0.418,0.518,0.600,0.737,0.925,0.979, 0.99999943514)
qs2007 <- c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6, f2007$wlth_eur[4])

#bracketavg
ba2007 <- vector("numeric", 12L)

for (i in 1:9){
  ba2007[i] <- bravg(s2007$agwlth, eq2007[i], eq2007[i+1])
}

for (i in 10:11){
  ba2007[i] <- thresholds_fit(ps2007, qs2007, average = 238700, bottom_model = 'dirac') %>% 
    bracket_average(ps2007[i], ps2007[i+1]) 
}
ba2007[12] <- mean(f2007$wlth_eur[f2007$wlth_eur > min(f2007$wlth_eur)])

dnbfit2007 <- tabulation_fit(ps2007, qs2007, bracketavg = ba2007, average = 238700, bottom_model = 'dirac')

dnb_forbes[15,2:4] <- as.list(top_share(dnbfit2007, c(0.99, 0.995, 0.999)))


##2008
f2008 <- read_xlsx("forbes_nl.xlsx", sheet = "2008")
d2008 <- read_dta("agw2008en_3.0.dta")
d2008[is.na(d2008)] <- 0
s2008 <- d2008 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2008 <- c(f2008$wlth_eur, s2008$agwlth) %>% sort(decreasing = TRUE)

summary(s2008$agwlth)
sd(s2008$agwlth)

s2008 %>% summarise(p99p100 = sum(s2008$agwlth[s2008$agwlth>=quantile(s2008$agwlth,0.99)]/sum(s2008$agwlth))) #0.0982

#quantiles
eq2008 <- ecdf(s2008$agwlth)(c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6))
ps2008 <- c(0.04,0.049,0.182,0.286,0.342,0.407,0.506,0.587,0.721,0.917,0.977, 0.99999944024)
qs2008 <- c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6, f2008$wlth_eur[4])

#bracketavg
ba2008 <- vector("numeric", 12L)

for(i in 1:9){
  ba2008[i] <- bravg(s2008$agwlth, eq2008[i], eq2008[i+1])
}
for (i in 10:11){
  ba2008[i] <- thresholds_fit(ps2008, qs2008, average = 243e3, bottom_model = 'dirac') %>% bracket_average(ps2008[i], ps2008[i+1])
}
ba2008[12] <- mean(f2008$wlth_eur[f2008$wlth_eur > min(f2008$wlth_eur)])

dnbfit2008 <- tabulation_fit(ps2008, qs2008, bracketavg = ba2008, average = 243e3, bottom_model = 'dirac')

dnb_forbes[16,2:4] <- as.list(top_share(dnbfit2008, c(0.99, 0.995, 0.999)))


##2009
f2009 <- read_xlsx("forbes_nl.xlsx", sheet = "2009")
d2009 <- read_dta("agw2009en_3.0.dta")
d2009[is.na(d2009)] <- 0
s2009 <- d2009 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2009 <- c(f2009$wlth_eur, s2009$agwlth) %>% sort(decreasing = TRUE)

summary(s2009$agwlth)
sd(s2009$agwlth)

s2009 %>% summarise(p99p100 = sum(s2009$agwlth[s2009$agwlth>=quantile(s2009$agwlth,0.99)]/sum(s2009$agwlth))) #0.0986

#quantiles
eq2009 <- ecdf(s2009$agwlth)(c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6))

ps2009 <- c(0.055,0.065,0.194,0.299,0.356,0.421,0.519,0.599,0.73, 0.92, 0.978, 0.99999958418)
qs2009 <- c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6, f2009$wlth_eur[3])

#bracketavg
ba2009 <- vector("numeric", 12L)

for (i in 1:9){
  ba2009[i] <- bravg(s2009$agwlth, eq2009[i], eq2009[i+1])
}
for (i in 10:11){
  ba2009[i] <- thresholds_fit(ps2009, qs2009, average = 232.4e3, bottom_model = 'dirac') %>% bracket_average(ps2009[i], ps2009[i+1])
}
ba2009[12] <- mean(f2009$wlth_eur[f2009$wlth_eur > min(f2009$wlth_eur)])

dnbfit2009 <- tabulation_fit(ps2009, qs2009, bracketavg = ba2009, average = 232.4e3, bottom_model = 'dirac')

dnb_forbes[17,2:4] <- as.list(top_share(dnbfit2009, c(0.99, 0.995, 0.999)))


##2010
# one observation with net worth of 500 billion, clear mistake and removed
f2010 <- read_xlsx("forbes_nl.xlsx", sheet = "2010")
d2010 <- read_dta("agw2010en_2.0.dta")
d2010[is.na(d2010)] <- 0
s2010 <- d2010 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth)) %>% filter(!agwlth > 1e7)
w2010 <- c(f2010$wlth_eur, s2010$agwlth) %>% sort(decreasing = TRUE)

summary(s2010$agwlth)
sd(s2010$agwlth)

s2010 %>% summarise(p99p100 = sum(s2010$agwlth[s2010$agwlth>=quantile(s2010$agwlth,0.99)]/sum(s2010$agwlth))) #0.0901

#quantiles
eq2010 <- ecdf(s2010$agwlth)(c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6))
ps2010 <- c(0.082,0.092,0.216,0.321,0.377,0.441,0.539,0.62, 0.749,0.924, 0.978, 0.9999993133)
qs2010 <- c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6, f2010$wlth_eur[5])

#bracketavg
ba2010 <- vector("numeric", 12L)

for (i in 1:9){
 ba2010[i] <- bravg(s2010$agwlth, eq2010[i], eq2010[i+1])
}
for (i in 10:11){
  ba2010[i] <- thresholds_fit(ps2010, qs2010, average = 226.9e3, bottom_model = 'dirac') %>% bracket_average(ps2010[i], ps2010[i+1])
}

ba2010[12] <- mean(f2010$wlth_eur[f2010$wlth_eur > min(f2010$wlth_eur)])

dnbfit2010 <- tabulation_fit(ps2010, qs2010, bracketavg = ba2010, average = 226.9e3, bottom_model = 'dirac')

dnb_forbes[18,2:4] <- as.list(top_share(dnbfit2010, c(0.99, 0.995, 0.999)))


##2011
f2011 <- read_xlsx("forbes_nl.xlsx", sheet = "2011")
d2011 <- read_dta("agw2011en_3.0.dta")
d2011[is.na(d2011)] <- 0
s2011 <- d2011 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2011 <- c(f2011$wlth_eur, s2011$agwlth) %>% sort(decreasing = TRUE)

summary(s2011$agwlth)
sd(s2011$agwlth)

s2011 %>% summarise(p99p100 = sum(s2011$agwlth[s2011$agwlth>=quantile(s2011$agwlth,0.99)]/sum(s2011$agwlth))) #0.0832

#quantiles
eq2011 <- ecdf(s2011$agwlth)(c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6))

ps2011 <- c(0.129,0.179,0.258,0.341,0.388,0.447,0.544,0.626,0.754,0.928, 0.978, 0.9999991834)
qs2011 <- c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6, min(f2011$wlth_eur))

#bracketavg
ba2011 <- vector("numeric", 12L)

for (i in 1:9){
  ba2011[i] <- bravg(s2011$agwlth, eq2011[i], eq2011[i+1])
}
for (i in 10:11){
  ba2011[i] <- thresholds_fit(ps2011, qs2011, average = 219.2e3, bottom_model = 'dirac') %>% bracket_average(ps2011[i],ps2011[i+1])
}
ba2011[12] <- mean(f2011$wlth_eur[f2011$wlth_eur > min(f2011$wlth_eur)])

dnbfit2011 <- tabulation_fit(ps2011, qs2011, bracketavg = ba2011, average = 219.2e3, bottom_model = 'dirac')

dnb_forbes[19,2:4] <- as.list(top_share(dnbfit2011, c(0.99, 0.995, 0.999)))


##2012
f2012 <- read_xlsx("forbes_nl.xlsx", sheet = "2012")
d2012 <- read_dta("agw2012en_3.0.dta")
d2012[is.na(d2012)] <- 0
s2012 <- d2012 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2012 <- c(f2012$wlth_eur, s2012$agwlth) %>% sort(decreasing = TRUE)

summary(s2012$agwlth)
sd(s2012$agwlth)

s2012 %>% summarise(p99p100 = sum(s2012$agwlth[s2012$agwlth>=quantile(s2012$agwlth,0.99)]/sum(s2012$agwlth))) #0.108

#quantiles
eq2012 <- ecdf(s2012$agwlth)(c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6))

ps2012 <- c(0.156,0.216,0.282,0.368,0.416,0.473,0.567,0.649,0.774,0.933, 0.979, 0.99999919051)
qs2012 <- c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6, min(f2012$wlth_eur))

#bracketavg
ba2012 <- vector("numeric", 12L)

for (i in 1:9){
  ba2012[i] <- bravg(s2012$agwlth, eq2012[i], eq2012[i+1])
}
for (i in 10:11){
  ba2012[i] <- thresholds_fit(ps2012, qs2012, average = 207.1e3, bottom_model = 'dirac') %>% bracket_average(ps2012[i], ps2012[i+1])
} 
ba2012[12] <- mean(f2012$wlth_eur[f2012$wlth_eur > min(f2012$wlth_eur)])

dnbfit2012 <- tabulation_fit(ps2012, qs2012, bracketavg = ba2012, average = 207.1e3, bottom_model = 'dirac')

dnb_forbes[20,2:4] <- as.list(top_share(dnbfit2012, c(0.99, 0.995, 0.999)))


##2013
f2013 <- read_xlsx("forbes_nl.xlsx", sheet = "2013")
d2013 <- read_dta("agw2013en_3.0.dta")
d2013[is.na(d2013)] <- 0
s2013 <- d2013 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2013 <- c(f2013$wlth_eur, s2013$agwlth) %>% sort(decreasing = TRUE)

summary(s2013$agwlth)
sd(s2013$agwlth)

s2013 %>% summarise(p99p100 = sum(s2013$agwlth[s2013$agwlth>=quantile(s2013$agwlth,0.99)]/sum(s2013$agwlth))) #0.104

#quantiles
eq2013 <- ecdf(s2013$agwlth)(c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6))
ps2013 <- c(0.193,0.252,0.327,0.415,0.46,0.513,0.598,0.679,0.801,0.94, 0.980, 0.99999919655)
qs2013 <- c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6, min(f2013$wlth_eur))

#bracketavg
ba2013 <- vector("numeric", 12L)

for (i in 1:9){
  ba2013[i] <- bravg(s2013$agwlth, eq2013[i], eq2013[i+1])
} 
for (i in 10:11){
  ba2013[i] <- thresholds_fit(ps2013, qs2013, average = 196.6e3, bottom_model = 'dirac') %>% bracket_average(ps2013[i], ps2013[i+1])
}  
ba2013[12] <- mean(f2013$wlth_eur[f2013$wlth_eur > min(f2013$wlth_eur)])

dnbfit2013 <- tabulation_fit(ps2013, qs2013, bracketavg = ba2013, average = 196.6e3, bottom_model = 'dirac')

dnb_forbes[21,2:4] <- as.list(top_share(dnbfit2013, c(0.99, 0.995, 0.999)))


##2014
f2014 <- read_xlsx("forbes_nl.xlsx", sheet = "2014")
d2014 <- read_dta("agw2014en_2.0.dta")
d2014[is.na(d2014)] <- 0
s2014 <- d2014 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2014 <- c(f2014$wlth_eur, s2014$agwlth) %>% sort(decreasing = TRUE)

summary(s2014$agwlth)
sd(s2014$agwlth)

s2014 %>% summarise(p99p100 = sum(s2014$agwlth[s2014$agwlth>=quantile(s2014$agwlth,0.99)]/sum(s2014$agwlth))) #0.106

#quantiles
eq2014 <- ecdf(s2014$agwlth)(c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6))
ps2014 <- c(0.194,0.254,0.329,0.418,0.462,0.514,0.599,0.68,0.801,0.94, 0.980, 0.99999906621)
qs2014 <- c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6, min(f2014$wlth_eur))

#bracketavg
ba2014 <- vector("numeric", 12L)

for (i in 1:9){
  ba2014[i] <- bravg(s2014$agwlth, eq2014[i], eq2014[i+1])
}
for (i in 10:11){
  ba2014[i] <- thresholds_fit(ps2014, qs2014, average = 201.9e3, bottom_model = 'dirac') %>% bracket_average(ps2014[i], ps2014[i+1])
}
ba2014[12] <- mean(f2014$wlth_eur[f2014$wlth_eur > min(f2014$wlth_eur)])

dnbfit2014 <- tabulation_fit(ps2014, qs2014, bracketavg = ba2014, average = 201.9e3, bottom_model = 'dirac')

dnb_forbes[22,2:4] <- as.list(top_share(dnbfit2014, c(0.99, 0.995, 0.999)))


##2015
f2015 <- read_xlsx("forbes_nl.xlsx", sheet = "2015")
d2015 <- read_dta("agw2015en_1.0.dta")
d2015[is.na(d2015)] <- 0
s2015 <- d2015 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2015 <- c(f2015$wlth_eur, s2015$agwlth) %>% sort(decreasing = TRUE)

summary(s2015$agwlth)
sd(s2015$agwlth)

s2015 %>% summarise(p99p100 = sum(s2015$agwlth[s2015$agwlth>=quantile(s2015$agwlth,0.99)]/sum(s2015$agwlth))) #0.107


#quantiles
eq2015 <- ecdf(s2015$agwlth)(c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6))

ps2015 <- c(0.178,0.236,0.301,0.392,0.441,0.499,0.591,0.672,0.793,0.938, 0.979, 0.99999881086)
qs2015 <- c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6, min(f2015$wlth_eur))

#bracketavg
ba2015 <- vector("numeric", 12L)

for (i in 1:9){
  ba2015[i] <- bravg(s2015$agwlth, eq2015[i], eq2015[i+1])
}  
for (i in 10:11){
  ba2015[i] <- thresholds_fit(ps2015, qs2015, average = 209.6e3, bottom_model = 'dirac') %>% bracket_average(ps2015[i], ps2015[i+1])
}  
ba2015[12] <- mean(f2015$wlth_eur[f2015$wlth_eur > min(f2015$wlth_eur)])

dnbfit2015 <- tabulation_fit(ps2015, qs2015, bracketavg = ba2015, average = 209.6e3, bottom_model = 'dirac')

dnb_forbes[23,2:4] <- as.list(top_share(dnbfit2015, c(0.99, 0.995, 0.999)))


##2016
f2016 <- read_xlsx("forbes_nl.xlsx", sheet = "2016")
d2016 <- read_dta("agw2016en_1.0.dta")
d2016[is.na(d2016)] <- 0
s2016 <- d2016 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))

w2016 <- c(f2016$wlth_eur, s2016$agwlth) %>% sort(decreasing = TRUE)

summary(s2016$agwlth)
sd(s2016$agwlth)

s2016 %>% summarise(p99p100 = sum(s2016$agwlth[s2016$agwlth>=quantile(s2016$agwlth,0.99)]/sum(s2016$agwlth))) #0.104

#quantiles
eq2016 <- ecdf(s2016$agwlth)(c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6))
ps2016 <- c(0.161,0.22,0.288,0.378,0.428,0.489,0.58, 0.664,0.785,0.934, 0.978, 0.99999881939)
qs2016 <- c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6, min(f2016$wlth_eur))

#bracketavg
ba2016 <- vector("numeric", 12L)

for (i in 1:9){
  ba2016[i] <- bravg(s2016$agwlth, eq2016[i], eq2016[i+1])
}
for (i in 10:11){
  ba2016[i] <- thresholds_fit(ps2016, qs2016, average = 217.2e3, bottom_model = 'dirac') %>% bracket_average(ps2016[i], ps2016[i+1])
}  
ba2016[12] <- mean(f2016$wlth_eur[f2016$wlth_eur > min(f2016$wlth_eur)])

dnbfit2016 <- tabulation_fit(ps2016, qs2016, bracketavg = ba2016, average = 217.2e3, bottom_model = 'dirac')

dnb_forbes[24,2:4] <- as.list(top_share(dnbfit2016, c(0.99, 0.995, 0.999)))


##2017
f2017 <- read_xlsx("forbes_nl.xlsx", sheet = "2017")
d2017 <- read_dta("agw2017en_1.0.dta")
d2017[is.na(d2017)] <- 0
s2017 <- d2017 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2017 <- c(f2017$wlth_eur, s2017$agwlth) %>% sort(decreasing = TRUE)

summary(s2017$agwlth)
sd(s2017$agwlth)

s2017 %>% summarise(p99p100 = sum(s2017$agwlth[s2017$agwlth>=quantile(s2017$agwlth,0.99)]/sum(s2017$agwlth))) #0.102

#quantiles
eq2017 <- ecdf(s2017$agwlth)(c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6))
ps2017 <- c(0.135,0.189,0.257,0.349,0.399,0.462,0.56, 0.646,0.769,0.929, 0.976, 0.99999870043)
qs2017 <- c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6, min(f2017$wlth_eur))

#bracketavg
ba2017 <- vector("numeric", 12L)

for (i in 1:9){
  ba2017[i] <- bravg(s2017$agwlth, eq2017[i], eq2017[i+1])
}  
for (i in 10:11){
  ba2017[i] <- thresholds_fit(ps2017, qs2017, average = 229800, bottom_model = 'dirac') %>% bracket_average(ps2017[i],ps2017[i+1])
} 
ba2017[12] <- mean(f2017$wlth_eur[f2017$wlth_eur > min(f2017$wlth_eur)])

dnbfit2017 <- tabulation_fit(ps2017, qs2017, bracketavg = ba2017, average = 229.8e3, bottom_model = 'dirac')

dnb_forbes[25,2:4] <- as.list(top_share(dnbfit2017, c(0.99, 0.995, 0.999)))


##2018
f2018 <- read_xlsx("forbes_nl.xlsx", sheet = "2018")
d2018 <- read_dta("agw2018en_1.0.dta")
d2018[is.na(d2018)] <- 0
s2018 <- d2018 %>% select(nohhold,ends_with("b")) %>% rowwise() %>% mutate(wlth = sum(b1b+b2b+b3b+b4b+b6b+b7b+b8b+b12b+b13b+b14b+b15b+b16b+b17b+b18b+b19ogb-b19hyb+b20b+b21b+b22b+b23b+b24b+b25b-s1b-s2b-s3b-s4b-s5b-s6b-s7b-s8b+b26ogb-b26hyb+b27ogb-b27hyb,na.rm=TRUE)) %>% group_by(nohhold) %>% summarise(agwlth = sum(wlth))
w2018 <- c(f2018$wlth_eur, s2018$agwlth) %>% sort(decreasing = TRUE)

summary(s2018$agwlth)
sd(s2018$agwlth)

s2018 %>% summarise(p99p100 = sum(s2018$agwlth[s2018$agwlth>=quantile(s2018$agwlth,0.99)]/sum(s2018$agwlth))) #0.0963

#quantiles
eq2018 <- ecdf(s2018$agwlth)(c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6))

ps2018 <- c(0.111,0.162,0.23,0.32, 0.368,0.429,0.53,0.62,0.745,0.918, 0.973, 0.99999883947)
qs2018 <- c(-5000,0,1000,5000,10000,20000,50000,100000,200000,500000,1e6, min(f2018$wlth_eur))

#bracketavg
ba2018 <- vector("numeric", 12L)

for (i in 1:9){
  ba2018[i] <- bravg(s2018$agwlth, eq2018[i], eq2018[i+1])
} 
for (i in 10:11){
  ba2018[i] <- thresholds_fit(ps2018, qs2018, average = 245.3e3, bottom_model = 'dirac') %>% bracket_average(ps2018[i], ps2018[i+1])
}  
ba2018[12] <- mean(f2018$wlth_eur[f2018$wlth_eur > min(f2018$wlth_eur)])

dnbfit2018 <- tabulation_fit(ps2018, qs2018, bracketavg = ba2018, average = 245.3e3, bottom_model = 'dirac')

dnb_forbes[26,2:4] <- as.list(top_share(dnbfit2018, c(0.99, 0.995, 0.999)))

write_csv(dnb_forbes, "dnb_forbes.csv")


## PART 2: OLS AND ML-HILL
# STEPWISE METHODOLOGY:
# 1. Merge DNB with Forbes
# 2. Rank observations according to wealth, in ascending order
# 3. Regress log rank on log wealth for households above the 99th percentile (~1MEUR)
# 4. Use found Pareto coefficient to infer top 1% share

#1993
fit_93 <- lm(log(rank(-w1993[w1993>=1e6])-0.5)~log(w1993[w1993>=1e6]))

summary(fit_93)

plot(log(w1993[w1993>=1e6]),log(rank(-w1993[w1993>=1e6])-0.5))
abline(fit_93)

pareto <- vector("numeric", length = 26L)

mle <- vector("numeric", length = 26L)

pareto[1] <- abs(fit_93$coefficients[2])

mle_93 <- alpha_hills(w1993[w1993>0], 1e6, value = TRUE)

mle[1] <- mle_93$shape

#1994

fit_94 <- lm(log(rank(-w1994[w1994>=1e6])-0.5)~log(w1994[w1994>=1e6]))

summary(fit_94)

pareto[2] <- abs(fit_94$coefficients[2])

mle_94 <- alpha_hills(w1994[w1994>0], 1e6, value = TRUE)

mle[2] <- mle_94$shape


#1995

fit_95 <- lm(log(rank(-w1995[w1995>=1e6])-0.5)~log(w1995[w1995>=1e6]))

summary(fit_95) #0.4

pareto[3] <- abs(fit_95$coefficients[2])

mle_95 <- alpha_hills(w1995[w1995>0], 1e6, value = TRUE)

mle[3] <- mle_95$shape


#1996

fit_96 <- lm(log(rank(-w1996[w1996>=1e6])-0.5)~log(w1996[w1996>=1e6]))

summary(fit_96) #0.38

pareto[4] <- abs(fit_96$coefficients[2])

mle_96 <- alpha_hills(w1996[w1996>0], 1e6, value = TRUE)

mle[4] <- mle_96$shape


# 1997

fit_97 <- lm(log(rank(-w1997[w1997>=1e6])-0.5)~log(w1997[w1997>=1e6]))

summary(fit_97) #0.34

pareto[5] <- abs(fit_97$coefficients[2])

mle_97 <- alpha_hills(w1997[w1997>0], 1e6, value = TRUE)

mle[5] <- mle_97$shape


# 1998

fit_98 <- lm(log(rank(-w1998[w1998>=1e6])-0.5)~log(w1998[w1998>=1e6]))

summary(fit_98) #0.4

pareto[6] <- abs(fit_98$coefficients[2])

mle_98 <- alpha_hills(w1998[w1998>0], 1e6, value = TRUE)

mle[6] <- mle_98$shape


# 1999

fit_99 <- lm(log(rank(-w1999[w1999>=1e6])-0.5)~log(w1999[w1999>=1e6]))

summary(fit_99) #0.23

pareto[7] <- abs(fit_99$coefficients[2])

mle_99 <- alpha_hills(w1999[w1999>0], 1e6, value = TRUE)

mle[7] <- mle_99$shape


# 2000

fit_00 <- lm(log(rank(-w2000[w2000>=1e6])-0.5)~log(w2000[w2000>=1e6]))

summary(fit_00) #0.32

pareto[8] <- abs(fit_00$coefficients[2])

mle_00 <- alpha_hills(w2000[w2000>0], 1e6, value = TRUE)

mle[8] <- mle_00$shape


# 2001

fit_01 <- lm(log(rank(-w2001[w2001>=1e6])-0.5)~log(w2001[w2001>=1e6]))

summary(fit_01) #0.48

pareto[9] <- abs(fit_01$coefficients[2])

mle_01 <- alpha_hills(w2001[w2001>0], 1e6, value = TRUE)

mle[9] <- mle_01$shape


# 2002

fit_02 <- lm(log(rank(-w2002[w2002>=1e6])-0.5)~log(w2002[w2002>=1e6]))

summary(fit_02) #0.64

pareto[10] <- abs(fit_02$coefficients[2])

mle_02 <- alpha_hills(w2002[w2002>0], 1e6, value = TRUE)

mle[10] <- mle_02$shape


# 2003

fit_03 <- lm(log(rank(-w2003[w2003>=1e6])-0.5)~log(w2003[w2003>=1e6]))

summary(fit_03) #0.27

pareto[11] <- abs(fit_03$coefficients[2])

mle_03 <- alpha_hills(w2003[w2003>0], 1e6, value = TRUE)

mle[11] <- mle_03$shape


# 2004

fit_04 <- lm(log(rank(-w2004[w2004>=1e6])-0.5)~log(w2004[w2004>=1e6]))

summary(fit_04) #0.28

pareto[12] <- abs(fit_04$coefficients[2])

mle_04 <- alpha_hills(w2004[w2004>0], 1e6, value = TRUE)

mle[12] <- mle_04$shape


# 2005

fit_05 <- lm(log(rank(-w2005[w2005>=1e6])-0.5)~log(w2005[w2005>=1e6]))

summary(fit_05) #0.3

pareto[13] <- abs(fit_05$coefficients[2])

mle_05 <- alpha_hills(w2005[w2005>0], 1e6, value = TRUE)

mle[13] <- mle_05$shape


# 2006

fit_06 <- lm(log(rank(-w2006[w2006>=1e6])-0.5)~log(w2006[w2006>=1e6]))

summary(fit_06) #0.27

pareto[14] <- abs(fit_06$coefficients[2])

mle_06 <- alpha_hills(w2006[w2006>0], 1e6, value = TRUE)

mle[14] <- mle_06$shape


# 2007

fit_07 <- lm(log(rank(-w2007[w2007>=1e6])-0.5)~log(w2007[w2007>=1e6]))

summary(fit_07) #0.32

pareto[15] <- abs(fit_07$coefficients[2])

mle_07 <- alpha_hills(w2007[w2007>0], 1e6, value = TRUE)

mle[15] <- mle_07$shape


# 2008

fit_08 <- lm(log(rank(-w2008[w2008>=1e6])-0.5)~log(w2008[w2008>=1e6]))

summary(fit_08) #0.28

pareto[16] <- abs(fit_08$coefficients[2])

mle_08 <- alpha_hills(w2008[w2008>0], 1e6, value = TRUE)

mle[16] <- mle_08$shape


# 2009

fit_09 <- lm(log(rank(-w2009[w2009>=1e6])-0.5)~log(w2009[w2009>=1e6]))

summary(fit_09) #0.32

ggplot(data = NULL, aes(x = log(w2009[w2009>=1e6]), y = log(rank(-w2009[w2009>=1e6])-0.5))) + geom_point() + geom_smooth(method = "lm", formula = y~x) +
  labs(x = "Log Wealth", y = "Log Rank - 1/2") + theme_classic() +
  scale_x_continuous(breaks = seq(14,23, by = 2))

pareto[17] <- abs(fit_09$coefficients[2])

mle_09 <- alpha_hills(w2009[w2009>0], 1e6, value = TRUE)

mle[17] <- mle_09$shape


# 2010

fit_10 <- lm(log(rank(-w2010[w2010>=1e6])-0.5)~log(w2010[w2010>=1e6]))

summary(fit_10) #0.29

pareto[18] <- abs(fit_10$coefficients[2])

mle_10 <- alpha_hills(w2010[w2010>0], 1e6, value = TRUE)

mle[18] <- mle_10$shape


# 2011

fit_11 <- lm(log(rank(-w2011[w2011>=1e6])-0.5)~log(w2011[w2011>=1e6]))

summary(fit_11) #0.28

pareto[19] <- abs(fit_11$coefficients[2])

mle_11 <- alpha_hills(w2011[w2011>0], 1e6, value = TRUE)

mle[19] <- mle_11$shape


# 2012

fit_12 <- lm(log(rank(-w2012[w2012>=1e6])-0.5)~log(w2012[w2012>=1e6]))

summary(fit_12) #0.31

pareto[20] <- abs(fit_12$coefficients[2])

mle_12 <- alpha_hills(w2012[w2012>0], 1e6, value = TRUE)

mle[20] <- mle_12$shape


# 2013

fit_13 <- lm(log(rank(-w2013[w2013>=1e6])-0.5)~log(w2013[w2013>=1e6]))

summary(fit_13) #0.24

pareto[21] <- abs(fit_13$coefficients[2])

mle_13 <- alpha_hills(w2013[w2013>0], 1e6, value = TRUE)

mle[21] <- mle_13$shape


# 2014

fit_14 <- lm(log(rank(-w2014[w2014>=1e6])-0.5)~log(w2014[w2014>=1e6]))

summary(fit_14) #0.23

pareto[22] <- abs(fit_14$coefficients[2])

mle_14 <- alpha_hills(w2014[w2014>0], 1e6, value = TRUE)

mle[22] <- mle_14$shape


# 2015

fit_15 <- lm(log(rank(-w2015[w2015>=1e6])-0.5)~log(w2015[w2015>=1e6]))

summary(fit_15) #0.26

pareto[23] <- abs(fit_15$coefficients[2])

mle_15 <- alpha_hills(w2015[w2015>0], 1e6, value = TRUE)

mle[23] <- mle_15$shape


# 2016

fit_16 <- lm(log(rank(-w2016[w2016>=1e6])-0.5)~log(w2016[w2016>=1e6]))

summary(fit_16) #0.27

pareto[24] <- abs(fit_16$coefficients[2])

mle_16 <- alpha_hills(w2016[w2016>0], 1e6, value = TRUE)

mle[24] <- mle_16$shape


# 2017

fit_17 <- lm(log(rank(-w2017[w2017>=1e6])-0.5)~log(w2017[w2017>=1e6]))

summary(fit_17) #0.27

pareto[25] <- abs(fit_17$coefficients[2])

mle_17 <- alpha_hills(w2017[w2017>0], 1e6, value = TRUE)

mle[25] <- mle_17$shape


# 2018

fit_18 <- lm(log(rank(-w2018[w2018>=1e6])-0.5)~log(w2018[w2018>=1e6]))

summary(fit_18) #0.24

pareto[26] <- abs(fit_18$coefficients[2])

mle_18 <- alpha_hills(w2018[w2018>0], 1e6, value = TRUE)

mle[26] <- mle_18$shape


year <- 1993:2018

p_gp <- vector("numeric", length = 26L)

p_gp[1] <- invpareto(dnbfit1993,0.99)/(invpareto(dnbfit1993,0.99)-1)
p_gp[2] <- invpareto(dnbfit1994,0.99)/(invpareto(dnbfit1994,0.99)-1)
p_gp[3] <- invpareto(dnbfit1995,0.99)/(invpareto(dnbfit1995,0.99)-1)
p_gp[4] <- invpareto(dnbfit1996,0.99)/(invpareto(dnbfit1996,0.99)-1)
p_gp[5] <- invpareto(dnbfit1997,0.99)/(invpareto(dnbfit1997,0.99)-1)
p_gp[6] <- invpareto(dnbfit1998,0.99)/(invpareto(dnbfit1998,0.99)-1)
p_gp[7] <- invpareto(dnbfit1999,0.99)/(invpareto(dnbfit1999,0.99)-1)
p_gp[8] <- invpareto(dnbfit2000,0.99)/(invpareto(dnbfit2000,0.99)-1)
p_gp[9] <- invpareto(dnbfit2001,0.99)/(invpareto(dnbfit2001,0.99)-1)
p_gp[10] <- invpareto(dnbfit2002,0.99)/(invpareto(dnbfit2002,0.99)-1)
p_gp[11] <- invpareto(dnbfit2003,0.99)/(invpareto(dnbfit2003,0.99)-1)
p_gp[12] <- invpareto(dnbfit2004,0.99)/(invpareto(dnbfit2004,0.99)-1)
p_gp[13] <- invpareto(dnbfit2005,0.99)/(invpareto(dnbfit2005,0.99)-1)
p_gp[14] <- invpareto(dnbfit2006,0.99)/(invpareto(dnbfit2006,0.99)-1)
p_gp[15] <- invpareto(dnbfit2007,0.99)/(invpareto(dnbfit2007,0.99)-1)
p_gp[16] <- invpareto(dnbfit2008,0.99)/(invpareto(dnbfit2008,0.99)-1)
p_gp[17] <- invpareto(dnbfit2009,0.99)/(invpareto(dnbfit2009,0.99)-1)
p_gp[18] <- invpareto(dnbfit2010,0.99)/(invpareto(dnbfit2010,0.99)-1)
p_gp[19] <- invpareto(dnbfit2011,0.99)/(invpareto(dnbfit2011,0.99)-1)
p_gp[20] <- invpareto(dnbfit2012,0.99)/(invpareto(dnbfit2012,0.99)-1)
p_gp[21] <- invpareto(dnbfit2013,0.99)/(invpareto(dnbfit2013,0.99)-1)
p_gp[22] <- invpareto(dnbfit2014,0.99)/(invpareto(dnbfit2014,0.99)-1)
p_gp[23] <- invpareto(dnbfit2015,0.99)/(invpareto(dnbfit2015,0.99)-1)
p_gp[24] <- invpareto(dnbfit2016,0.99)/(invpareto(dnbfit2016,0.99)-1)
p_gp[25] <- invpareto(dnbfit2017,0.99)/(invpareto(dnbfit2017,0.99)-1)
p_gp[26] <- invpareto(dnbfit2018,0.99)/(invpareto(dnbfit2018,0.99)-1)

dnb_pareto <- tibble(year, pareto,mle, p_gp)

write_csv(dnb_pareto, "dnb_pareto.csv")


## PART 3: ROBUST PARETO REGRESSION DATA GENERATION
## Panel data generations
## Stepwise methodology:
## 1. Extract data from objects above
## 2. Define functions sublm() and submle(), that work on ever narrowing subsets
##    of data.
## 3. Use sublm() and submle() to generate data for Robust Pareto Regression.
## 4. Check whether gpinter() is workable.
## 5. Combine all data into a single dataset.

dnblist <- c(ls.str(pattern = "s1", mode = "list"),ls.str(pattern = "s2", mode = "list"))

dnb_list <- list()

for (i in dnblist){
  dnb_list[[i]] <- get(i)
}

wlth <- vector()

for (i in 1:26){
  vec <- dnb_list[[i]][[2]]
  wlth <- c(wlth, vec)
}

slength <- vector()

for (i in 1:26){
  slength[i] <- length(dnb_list[[i]][[2]])
}

yval <- 1993:2018

year <- rep(yval, slength)

hh <- rep(slength, slength)

dnb_wlth <- tibble(year, wlth, hh)

p595 <- dnb_wlth %>% group_by(year) %>% summarise(p05 = quantile(wlth, 0.05), p95 = quantile(wlth, 0.95))

# convert GLD values to EUR
gld_eur <- c(1.75, 1.8, 1.83, 1.87, 1.91, 1.95, 2, 2.04, 2.13)

for (i in 1:9){
  dnb_wlth$wlth[dnb_wlth$year == yval[i]] <- dnb_wlth$wlth/gld_eur[i]
}

sublm <- function(data, q){
  data %>% filter(wlth > q) %>% 
    group_by(year, hh) %>% filter(n() >= 10) %>% 
    do(fit = lm(log(rank(-wlth) - 0.5) ~ log(wlth), data = .)) %>%
    do(data.frame(
      year = .$year,
      q = q,
      d = "dnb",
      m = "ols",
      log_p = log( 1 - (.$hh - nobs(.$fit))/.$hh),
      z = -coef(summary(.$fit))[2]
    ))
}

ols_data <- tibble()

thr <- vector()

for (i in 1:4){
  thr[1] <- 500e3
  thr[i+1] <- 2*thr[i]
}

for (i in seq_along(thr)){
  result <- sublm(dnb_wlth, thr[i])
  dat <- as_tibble(result)
  ols_data <- rbind(ols_data, dat)
}


submle <- function(data, q){
  data %>% filter(wlth > q) %>% group_by(year) %>% filter(n() >= 10) %>%
    do(fit = alpha_hills(.$wlth[.$wlth>0], q, value = TRUE)) %>% 
    do(data.frame(
      year = .$year,
      q = q,
      d = "dnb",
      m = "mle",
      z = .$fit[[1]]))
}

mle_data <- tibble()

for (q in seq_along(thr)){
  result <- submle(dnb_wlth, thr[q])
  dat <- as_tibble(result)
  mle_data <- rbind(mle_data, dat)
}

mle_data <- mle_data  %>% filter(!is.infinite(z))

balist <- ls.str(pattern = "ba", mode = "numeric")
qslist <- ls.str(pattern = "qs", mode = "numeric")
pslist <- ls.str(pattern = "ps", mode = "numeric")

ba_list <- list()
qs_list <- list()
ps_list <- list()

ba <- vector()
for (i in balist){
  ba_list[[i]] <- get(i)
  vec <- ba_list[[i]]
  ba <- c(ba, vec)
}

qs <- vector()
for (i in qslist){
  qs_list[[i]] <- get(i)
  vec <- qs_list[[i]]
  qs <- c(qs, vec)
}

ps <- vector()
for (i in pslist){
  ps_list[[i]] <- get(i)
  vec <- ps_list[[i]]
  ps <- c(ps, vec)
}

gplength <- vector()
for (i in 1:26){
  gplength[i] <- length(ba_list[[i]])
}

year_gp <- rep(yval, gplength)

avg <- 1000*c(76.5,	79.1,	108.6,	117.4,	129.6,	140.8,	161.7,	181.2,	192.5,	198.9, 202.9,	213.3,	219.4,	230.7,	238.7,	243.0,	232.4,	226.9,	219.2,	207.1,	196.6,	201.9,	209.6,	217.2,	229.8,	245.3
)

gp_input <- tibble(year_gp, ps, qs, ba) %>% arrange(desc(ps)) %>% group_by(year_gp) %>% slice(-c(1:2)) %>% arrange(year_gp, ps)

gp_data <- tibble()

b <- vector()
z <- vector()

for (i in seq_along(thr)){
  p <- gp_input %>% filter(year_gp == yval[i]) %>% select(ps)
  q <- gp_input %>% filter(year_gp == yval[i]) %>% select(qs)
  a <- gp_input %>% filter(year_gp == yval[i]) %>% select(ba)
  fit <- tabulation_fit(p[[2]], q[[2]], bracketavg = a[[2]], average = avg[i], bottom_model = "dirac")
  b[i] <- invpareto(fit, fitted_cdf(fit, 1e6))
  z[i] <- b[i]/(b[i]-1)
  print(z)
}

# again, no useful material

df_dnb <- full_join(ols_data, mle_data)

df_dnb <- df_dnb %>% group_by(year, q) %>% mutate(log_p = ifelse(m == "ols", log_p, log_p[m == "ols"]))

write_csv(df_dnb, "df_dnb.csv")
