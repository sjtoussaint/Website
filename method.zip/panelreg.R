pacman::p_load(haven,tidyverse, gpinter, readxl, ptsuite, AER, lfe, sandwich, estimatr, broom, fixest, stargazer)

theme_set(theme_classic())

cbs <- read_csv("df_cbs.csv")
sep <- read_csv("df_sep.csv")
dnb <- read_csv("df_dnb.csv")
forbes <- read_csv("df_forbes.csv")
quote <- read_csv("df_quote.csv")

df <- full_join(cbs, sep) %>% bind_rows(dnb, forbes, quote)

summary(df)

plot(density(df$z))

df <- df %>% select(-cdf)

df <- df %>% mutate(w = -log(q), year = year - 1992)

# remove MLE estimate for forbes (which is duplicate of the gpinter estimate)

df <- df[!(df$d == "forbes" & df$m == "mle"),]



pfit_a <- felm(log_p ~ w + i(w, d, drop = "cbs") + d + year, data = df)

summary(pfit_a)

pfit_a_tidy <- pfit_a %>% tidy()

pfit_b <- felm(log_p ~ w + i(w, d, drop = "cbs") + d + i(rep(1, length(year)), year, drop = 1), data = df)

summary(pfit_b)

pfit_b_tidy <- pfit_b %>% tidy()

pfit_c <- felm(log_p ~ w + i(w, d, drop = "cbs") + d + i(w, year, 1), data = df)

summary(pfit_c)

pfit_c_tidy <- tidy(pfit_c)

pfit_c_tidy %>% slice(11:35) %>% mutate(year = 1994:2018) %>%
  ggplot(aes(x = year, y = estimate, ymin = estimate - 1.96*std.error, ymax = estimate + 1.96*std.error)) +
  geom_pointrange() + geom_abline(aes(slope = 0, intercept = 0)) +
  scale_x_continuous(breaks = seq(1994, 2018, by = 4)) + 
  labs(x = "Year", y = "Estimate") + 
  ggtitle(expression(paste("Annual Trend In Pareto Coefficient ", xi)))

pfit_c_tidy %>% slice(2:5) %>%
  ggplot(aes(x = term, y = estimate, ymin = estimate - 1.96*std.error, ymax = estimate + 1.96*std.error)) +
  geom_pointrange() + 
  geom_abline(aes(slope = 0, intercept = 0)) +
  scale_x_discrete(labels = c("DNB", "Forbes", "Quote", "SEP")) + 
  labs(x = "Year", y = "Estimate") + 
  ggtitle(expression(paste("Differences In Pareto Coefficient ", xi, " Between Datasets")))

pfit_c_tidy %>% slice(6:9) %>%
  ggplot(aes(x = term, y = estimate, ymin = estimate - 1.96*std.error, ymax = estimate + 1.96*std.error)) +
  geom_pointrange() + 
  scale_x_discrete(labels = c("DNB", "Forbes", "Quote", "SEP")) + 
  labs(x = "Year", y = "Estimate") + 
  ggtitle(expression(paste("Differences In Scale Parameter ", chi, " Between Datasets")))


zfit_a <- felm(z ~ d + as.factor(year), data = df)

summary(zfit_a)

zfit_a_tidy <- zfit_a %>% tidy()

zfit_a_tidy %>% slice(6:30) %>% mutate(year = 1994:2018) %>%
  ggplot(aes(x = year, y = estimate, ymin = estimate - 1.96*std.error, ymax = estimate + 1.96*std.error)) + 
  geom_pointrange() + geom_abline(aes(slope = 0, intercept = 0)) +
  scale_x_continuous(breaks = seq(1994, 2018, by = 4)) + 
  labs(x = "Year", y = "Estimate") + 
  ggtitle(expression(paste("Annual Trend In Pareto Coefficient ", xi)))

zfit_a_tidy %>% slice(2:5) %>% 
  ggplot(aes(x = term, y = estimate, ymin = estimate - 1.96*std.error, ymax = estimate + 1.96*std.error)) +
  geom_pointrange() + geom_abline(aes(slope = 0, intercept = 0)) +
  labs(x = "Data Source", y = "Estimate") +
  scale_x_discrete(labels = c("DNB", "Forbes", "Quote", "SEP")) +
  ggtitle(expression(paste("Differences in Pareto Coefficient ", xi, " Per Data Source")))


plot(df$w, pfit_a$residuals, main = "(1)", xlab = "-w", ylab = "Residuals")
abline(0, 0)

plot(df$w, pfit_b$residuals, main = "(2)", xlab = "-w", ylab = "Residuals")
abline(0, 0)

plot(df$w, pfit_c$residuals, main = "(3)", xlab = "-w", ylab = "Residuals")
abline(0, 0)

plot(df$w, zfit_a$residuals, main = "(4)", xlab = "-w", ylab = "Residuals")
abline(0 , 0)


## robustness: clustering se

pfit_a_cl <- felm(log_p ~ w + i(w, d, drop = "cbs") + d + year | 0 | 0 | d + year, data = df)

summary(pfit_a_cl)

pfit_b_cl <- felm(log_p ~ w + i(w, d, drop = "cbs") + d + as.factor(year) | 0 | 0 | d + year, data = df)

summary(pfit_b_cl)

pfit_c_cl <- felm(log_p ~ w + i(w, d, drop = "cbs") + d + i(w, year, drop = 1) + as.factor(year) |0 | 0 | d + year, data = df)

summary(pfit_c_cl)


pfit_c_cl %>% tidy() %>% slice(11:35) %>% mutate(year = 1994:2018) %>%
  ggplot(aes(x = year, y = estimate, ymin = estimate - 1.96*std.error, ymax = estimate + 1.96*std.error)) +
  geom_pointrange() + 
  geom_abline(aes(slope = 0, intercept = 0)) +
  scale_x_continuous(breaks = seq(1994, 2018, by = 4)) + 
  labs(x = "Year", y = "Estimate") + 
  ggtitle(expression(paste("Annual Trend In Pareto Coefficient ", xi)))

zfit_a_cl <- felm(z ~ d + as.factor(year) | 0 | 0 | d + year, data = df)

summary(zfit_a_cl)



df %>% mutate(year = year+1992, w = -w) %>% 
  group_by(year) %>% filter(year == 2002) %>%
  ggplot(aes(x = -w, y = log_p, color = d)) + geom_point() +
  labs(x = "-w", y =  "log P", color = "Data Source") + 
  theme(axis.title.y = element_text(angle = 0))

df %>% mutate(year = year+1992, w = w) %>% 
  group_by(d) %>%
  ggplot(aes(x = w, y = z, color = d)) + geom_point() +
  labs(x = "", y =  "(E - w)^-1", color = "Data Source") + 
  theme(axis.title.y = element_text(angle = 0))

df %>% mutate(year = year+1993, w = w) %>%
  group_by(d) %>%
  ggplot(aes(x = w, y = log_p, color = d)) + geom_point() +
  labs(x = "-w", y =  "log P", color = "Data Source") + 
  theme(axis.title.y = element_text(angle = 0))

df %>% filter(year == 10, d == "cbs") %>% lm_robust(log_p ~ w, data = .) %>% summary()

fullreg <- felm(log_p ~ w + i(w, d, drop = "cbs") + d + i(w, year, 1) + as.factor(year), data = df)

fullreg_tidy <- fullreg %>% tidy()

fullreg_tidy %>% slice(11:35) %>% mutate(year = 1994:2018) %>%
  ggplot(aes(x = year, y = estimate, ymin = estimate - 1.96*std.error, ymax = estimate + 1.96*std.error)) +
  geom_pointrange() + geom_abline(aes(slope = 0, intercept = 0)) +
  scale_x_continuous(breaks = seq(1994, 2018, by = 4)) + 
  labs(x = "Year", y = "Estimate") + 
  ggtitle(expression(paste("Annual Trend In Pareto Coefficient ", xi)))


fullreg_tidy %>% slice(36:60) %>% mutate(year = 1994:2018) %>%
  ggplot(aes(x = year, y = estimate, ymin = estimate - 1.96*std.error, ymax = estimate + 1.96*std.error)) +
  geom_pointrange() + geom_abline(aes(slope = 0, intercept = 0)) +
  scale_x_continuous(breaks = seq(1994, 2018, by = 4)) + 
  labs(x = "Year", y = "Estimate") + 
  ggtitle(expression(paste("Annual Trend In Scale Parameter ", chi)))

fullreg_tidy %>% slice(3:6) %>% 
  ggplot(aes(x = term, y = estimate, ymin = estimate - 1.96*std.error, ymax = estimate + 1.96*std.error)) +
  geom_pointrange() + geom_abline(aes(slope = 0, intercept = 0)) +
  labs(x = "Data Source", y = "Estimate") +
  scale_x_discrete(labels = c("DNB", "Forbes", "Quote", "SEP")) +
  ggtitle(expression(paste("Differences in Pareto Coefficient ", xi, " Per Data Source")))

fullreg_tidy %>% slice(7:10) %>% 
  ggplot(aes(x = term, y = estimate, ymin = estimate - 1.96*std.error, ymax = estimate + 1.96*std.error)) +
  geom_pointrange() + geom_abline(aes(slope = 0, intercept = 0)) +
  labs(x = "Data Source", y = "Estimate") +
  scale_x_discrete(labels = c("DNB", "Forbes", "Quote", "SEP")) +
  ggtitle(expression(paste("Differences in Scale Parameter ", chi, " Per Data Source")))

stargazer(list(pfit_a, pfit_b, pfit_c, fullreg, zfit_a), intercept.bottom = FALSE, intercept.top = TRUE)
